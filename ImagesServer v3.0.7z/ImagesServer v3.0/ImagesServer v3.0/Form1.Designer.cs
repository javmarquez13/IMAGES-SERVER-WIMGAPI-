﻿namespace ImagesServer_v3._0
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

 

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnMinimize = new System.Windows.Forms.Button();
            this.lblVersion = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel20 = new System.Windows.Forms.Panel();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lbAllDrives_settings = new System.Windows.Forms.ListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnRemoveDrive_settings = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cbLetterToRemove_settings = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnMap_settings = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.cbDomain_settings = new System.Windows.Forms.ComboBox();
            this.txtPassword_settings = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUser_settings = new System.Windows.Forms.TextBox();
            this.txtServer_settings = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbLetter_settings = new System.Windows.Forms.ComboBox();
            this.btnRefreshDrives_settings = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btn_ImagexApply = new System.Windows.Forms.Button();
            this.btnApply_Refresh = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.rbtnFactory_apply = new System.Windows.Forms.RadioButton();
            this.rbtnUser_apply = new System.Windows.Forms.RadioButton();
            this.rbtnSite_apply = new System.Windows.Forms.RadioButton();
            this.lbImagesToApply_apply = new System.Windows.Forms.ListBox();
            this.lbImagesServer_apply = new System.Windows.Forms.ListBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnApply_apply = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblCountFiles = new System.Windows.Forms.Label();
            this.btnAbortWimgapi = new System.Windows.Forms.Button();
            this.lblFilesInfo = new System.Windows.Forms.Label();
            this.btnCaptureWimGapi = new System.Windows.Forms.Button();
            this.btnCaptureImageX = new System.Windows.Forms.Button();
            this.btnCapture_Refresh = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rbtnFactory_capture = new System.Windows.Forms.RadioButton();
            this.rbtnUser_catpure = new System.Windows.Forms.RadioButton();
            this.rbtnSite_capture = new System.Windows.Forms.RadioButton();
            this.lvFilesView_capture = new System.Windows.Forms.ListView();
            this.btnCapture_capture = new System.Windows.Forms.Button();
            this.txtImageName_capture = new System.Windows.Forms.TextBox();
            this.lbSaveImage_capture = new System.Windows.Forms.ListBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lvPartition_capture = new System.Windows.Forms.ListView();
            this.lvDescription_capture = new System.Windows.Forms.ListView();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pBoxWaiting2 = new System.Windows.Forms.PictureBox();
            this.pBoxWaiting1 = new System.Windows.Forms.PictureBox();
            this.pBoxStatus = new System.Windows.Forms.PictureBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblID = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblImageName = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.lblSN = new System.Windows.Forms.Label();
            this.lblMC = new System.Windows.Forms.Label();
            this.lblClass = new System.Windows.Forms.Label();
            this.lblTracer = new System.Windows.Forms.Label();
            this.btnTestImage_sscos = new System.Windows.Forms.Button();
            this.btnCustomOS_sscos = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.txtSlotInfo = new System.Windows.Forms.TextBox();
            this.btnTab1 = new System.Windows.Forms.Button();
            this.btnTab2 = new System.Windows.Forms.Button();
            this.btnTab3 = new System.Windows.Forms.Button();
            this.btnTab4 = new System.Windows.Forms.Button();
            this.lblProgress = new System.Windows.Forms.Label();
            this.lblEstimatedTime = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxWaiting2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxWaiting1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxStatus)).BeginInit();
            this.panel8.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btnExit);
            this.panel1.Controls.Add(this.btnMinimize);
            this.panel1.Location = new System.Drawing.Point(-4, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1682, 49);
            this.panel1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(93)))), ((int)(((byte)(0)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button1.Location = new System.Drawing.Point(1515, 5);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(45, 45);
            this.button1.TabIndex = 37;
            this.button1.Text = "?";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.BackColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.IndianRed;
            this.btnExit.FlatAppearance.BorderSize = 0;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExit.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnExit.Location = new System.Drawing.Point(1630, 3);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(45, 45);
            this.btnExit.TabIndex = 35;
            this.btnExit.Text = "X";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnMinimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(93)))), ((int)(((byte)(0)))));
            this.btnMinimize.FlatAppearance.BorderSize = 0;
            this.btnMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMinimize.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnMinimize.Location = new System.Drawing.Point(1574, 5);
            this.btnMinimize.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(45, 45);
            this.btnMinimize.TabIndex = 36;
            this.btnMinimize.Text = "_";
            this.btnMinimize.UseVisualStyleBackColor = false;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // lblVersion
            // 
            this.lblVersion.AutoSize = true;
            this.lblVersion.BackColor = System.Drawing.Color.Transparent;
            this.lblVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVersion.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblVersion.Location = new System.Drawing.Point(308, 60);
            this.lblVersion.Name = "lblVersion";
            this.lblVersion.Size = new System.Drawing.Size(69, 17);
            this.lblVersion.TabIndex = 12;
            this.lblVersion.Text = "VERSION";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(12, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(289, 36);
            this.label4.TabIndex = 11;
            this.label4.Text = "IMAGES-SERVER ";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // panel20
            // 
            this.panel20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.panel20.Location = new System.Drawing.Point(-2, 905);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(1678, 63);
            this.panel20.TabIndex = 14;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage5.Controls.Add(this.lbAllDrives_settings);
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Controls.Add(this.btnRefreshDrives_settings);
            this.tabPage5.Controls.Add(this.label2);
            this.tabPage5.Controls.Add(this.label1);
            this.tabPage5.Location = new System.Drawing.Point(4, 29);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1670, 742);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Network drives";
            // 
            // lbAllDrives_settings
            // 
            this.lbAllDrives_settings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbAllDrives_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lbAllDrives_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lbAllDrives_settings.FormattingEnabled = true;
            this.lbAllDrives_settings.ItemHeight = 20;
            this.lbAllDrives_settings.Location = new System.Drawing.Point(1107, 55);
            this.lbAllDrives_settings.Name = "lbAllDrives_settings";
            this.lbAllDrives_settings.Size = new System.Drawing.Size(500, 244);
            this.lbAllDrives_settings.TabIndex = 47;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnRemoveDrive_settings);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.cbLetterToRemove_settings);
            this.groupBox2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox2.Location = new System.Drawing.Point(10, 397);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(240, 134);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Remove drive:";
            // 
            // btnRemoveDrive_settings
            // 
            this.btnRemoveDrive_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnRemoveDrive_settings.FlatAppearance.BorderSize = 0;
            this.btnRemoveDrive_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRemoveDrive_settings.Location = new System.Drawing.Point(72, 42);
            this.btnRemoveDrive_settings.Name = "btnRemoveDrive_settings";
            this.btnRemoveDrive_settings.Size = new System.Drawing.Size(150, 69);
            this.btnRemoveDrive_settings.TabIndex = 44;
            this.btnRemoveDrive_settings.Text = "REMOVE";
            this.btnRemoveDrive_settings.UseVisualStyleBackColor = false;
            this.btnRemoveDrive_settings.Click += new System.EventHandler(this.btnRemoveDrive_settings_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(8, 38);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 20);
            this.label9.TabIndex = 45;
            this.label9.Text = "Letter:";
            // 
            // cbLetterToRemove_settings
            // 
            this.cbLetterToRemove_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.cbLetterToRemove_settings.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLetterToRemove_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.cbLetterToRemove_settings.FormattingEnabled = true;
            this.cbLetterToRemove_settings.Items.AddRange(new object[] {
            "A:",
            "B:",
            "C:",
            "D:",
            "E:",
            "F:",
            "G:",
            "H:",
            "I:",
            "J:",
            "K:",
            "L:",
            "M:",
            "N:",
            "O:",
            "P:",
            "Q:",
            "R:",
            "S:",
            "T:",
            "U:",
            "V:",
            "W:",
            "X:",
            "Y:",
            "Z:"});
            this.cbLetterToRemove_settings.Location = new System.Drawing.Point(8, 65);
            this.cbLetterToRemove_settings.Name = "cbLetterToRemove_settings";
            this.cbLetterToRemove_settings.Size = new System.Drawing.Size(58, 28);
            this.cbLetterToRemove_settings.TabIndex = 44;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMap_settings);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.cbDomain_settings);
            this.groupBox1.Controls.Add(this.txtPassword_settings);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtUser_settings);
            this.groupBox1.Controls.Add(this.txtServer_settings);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cbLetter_settings);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Location = new System.Drawing.Point(10, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(522, 318);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add drive:";
            // 
            // btnMap_settings
            // 
            this.btnMap_settings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMap_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnMap_settings.FlatAppearance.BorderSize = 0;
            this.btnMap_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMap_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnMap_settings.Location = new System.Drawing.Point(362, 238);
            this.btnMap_settings.Name = "btnMap_settings";
            this.btnMap_settings.Size = new System.Drawing.Size(150, 69);
            this.btnMap_settings.TabIndex = 30;
            this.btnMap_settings.Text = "MAP";
            this.btnMap_settings.UseVisualStyleBackColor = false;
            this.btnMap_settings.Click += new System.EventHandler(this.btnMap_settings_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Location = new System.Drawing.Point(18, 238);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 20);
            this.label8.TabIndex = 43;
            this.label8.Text = "Password:";
            // 
            // cbDomain_settings
            // 
            this.cbDomain_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.cbDomain_settings.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDomain_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.cbDomain_settings.FormattingEnabled = true;
            this.cbDomain_settings.Items.AddRange(new object[] {
            "JABIL\\"});
            this.cbDomain_settings.Location = new System.Drawing.Point(18, 132);
            this.cbDomain_settings.Name = "cbDomain_settings";
            this.cbDomain_settings.Size = new System.Drawing.Size(104, 28);
            this.cbDomain_settings.TabIndex = 38;
            // 
            // txtPassword_settings
            // 
            this.txtPassword_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.txtPassword_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtPassword_settings.Location = new System.Drawing.Point(18, 262);
            this.txtPassword_settings.Name = "txtPassword_settings";
            this.txtPassword_settings.PasswordChar = '*';
            this.txtPassword_settings.Size = new System.Drawing.Size(262, 26);
            this.txtPassword_settings.TabIndex = 42;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Location = new System.Drawing.Point(18, 109);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 20);
            this.label6.TabIndex = 39;
            this.label6.Text = "Domain:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(18, 178);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 20);
            this.label7.TabIndex = 41;
            this.label7.Text = "User:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(18, 38);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 20);
            this.label3.TabIndex = 36;
            this.label3.Text = "Letter:";
            // 
            // txtUser_settings
            // 
            this.txtUser_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.txtUser_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtUser_settings.Location = new System.Drawing.Point(18, 202);
            this.txtUser_settings.Name = "txtUser_settings";
            this.txtUser_settings.Size = new System.Drawing.Size(262, 26);
            this.txtUser_settings.TabIndex = 40;
            // 
            // txtServer_settings
            // 
            this.txtServer_settings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServer_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.txtServer_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtServer_settings.Location = new System.Drawing.Point(104, 66);
            this.txtServer_settings.Name = "txtServer_settings";
            this.txtServer_settings.Size = new System.Drawing.Size(412, 26);
            this.txtServer_settings.TabIndex = 29;
            this.txtServer_settings.Text = "Example: \\\\mxchim0rel01\\ncr";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(100, 38);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 20);
            this.label5.TabIndex = 37;
            this.label5.Text = "Server:";
            // 
            // cbLetter_settings
            // 
            this.cbLetter_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.cbLetter_settings.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLetter_settings.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.cbLetter_settings.FormattingEnabled = true;
            this.cbLetter_settings.Items.AddRange(new object[] {
            "A:",
            "B:",
            "C:",
            "D:",
            "E:",
            "F:",
            "G:",
            "H:",
            "I:",
            "J:",
            "K:",
            "L:",
            "M:",
            "N:",
            "O:",
            "P:",
            "Q:",
            "R:",
            "S:",
            "T:",
            "U:",
            "V:",
            "W:",
            "X:",
            "Y:",
            "Z:"});
            this.cbLetter_settings.Location = new System.Drawing.Point(18, 65);
            this.cbLetter_settings.Name = "cbLetter_settings";
            this.cbLetter_settings.Size = new System.Drawing.Size(58, 28);
            this.cbLetter_settings.TabIndex = 35;
            // 
            // btnRefreshDrives_settings
            // 
            this.btnRefreshDrives_settings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRefreshDrives_settings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnRefreshDrives_settings.FlatAppearance.BorderSize = 0;
            this.btnRefreshDrives_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRefreshDrives_settings.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnRefreshDrives_settings.Location = new System.Drawing.Point(1456, 317);
            this.btnRefreshDrives_settings.Name = "btnRefreshDrives_settings";
            this.btnRefreshDrives_settings.Size = new System.Drawing.Size(150, 69);
            this.btnRefreshDrives_settings.TabIndex = 33;
            this.btnRefreshDrives_settings.Text = "REFRESH";
            this.btnRefreshDrives_settings.UseVisualStyleBackColor = false;
            this.btnRefreshDrives_settings.Click += new System.EventHandler(this.btnRefreshDrives_settings_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Location = new System.Drawing.Point(1102, 26);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(264, 20);
            this.label2.TabIndex = 31;
            this.label2.Text = "VIEW ALL DRIVES MAPPING:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Location = new System.Drawing.Point(8, 26);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 20);
            this.label1.TabIndex = 28;
            this.label1.Text = "CONNECT TO SERVER:";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage4.Controls.Add(this.btn_ImagexApply);
            this.tabPage4.Controls.Add(this.btnApply_Refresh);
            this.tabPage4.Controls.Add(this.groupBox4);
            this.tabPage4.Controls.Add(this.lbImagesToApply_apply);
            this.tabPage4.Controls.Add(this.lbImagesServer_apply);
            this.tabPage4.Controls.Add(this.label13);
            this.tabPage4.Controls.Add(this.label12);
            this.tabPage4.Controls.Add(this.btnApply_apply);
            this.tabPage4.Controls.Add(this.label11);
            this.tabPage4.Controls.Add(this.label10);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1670, 742);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Apply image";
            // 
            // btn_ImagexApply
            // 
            this.btn_ImagexApply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btn_ImagexApply.FlatAppearance.BorderSize = 0;
            this.btn_ImagexApply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_ImagexApply.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btn_ImagexApply.Location = new System.Drawing.Point(468, 589);
            this.btn_ImagexApply.Name = "btn_ImagexApply";
            this.btn_ImagexApply.Size = new System.Drawing.Size(150, 69);
            this.btn_ImagexApply.TabIndex = 56;
            this.btn_ImagexApply.Text = "APPLY IMAGEX";
            this.btn_ImagexApply.UseVisualStyleBackColor = false;
            this.btn_ImagexApply.Click += new System.EventHandler(this.btn_ImagexApply_Click);
            // 
            // btnApply_Refresh
            // 
            this.btnApply_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnApply_Refresh.FlatAppearance.BorderSize = 0;
            this.btnApply_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply_Refresh.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnApply_Refresh.Location = new System.Drawing.Point(312, 512);
            this.btnApply_Refresh.Name = "btnApply_Refresh";
            this.btnApply_Refresh.Size = new System.Drawing.Size(150, 69);
            this.btnApply_Refresh.TabIndex = 55;
            this.btnApply_Refresh.Text = "REFRESH";
            this.btnApply_Refresh.UseVisualStyleBackColor = false;
            this.btnApply_Refresh.Click += new System.EventHandler(this.btnApply_Refresh_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.rbtnFactory_apply);
            this.groupBox4.Controls.Add(this.rbtnUser_apply);
            this.groupBox4.Controls.Add(this.rbtnSite_apply);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox4.Location = new System.Drawing.Point(662, 54);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(346, 74);
            this.groupBox4.TabIndex = 54;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Apply mode:";
            // 
            // rbtnFactory_apply
            // 
            this.rbtnFactory_apply.AutoSize = true;
            this.rbtnFactory_apply.Location = new System.Drawing.Point(168, 29);
            this.rbtnFactory_apply.Name = "rbtnFactory_apply";
            this.rbtnFactory_apply.Size = new System.Drawing.Size(117, 24);
            this.rbtnFactory_apply.TabIndex = 54;
            this.rbtnFactory_apply.Text = "FACTORY";
            this.rbtnFactory_apply.UseVisualStyleBackColor = true;
            this.rbtnFactory_apply.CheckedChanged += new System.EventHandler(this.rbtnFactory_apply_CheckedChanged);
            // 
            // rbtnUser_apply
            // 
            this.rbtnUser_apply.AutoSize = true;
            this.rbtnUser_apply.Location = new System.Drawing.Point(82, 29);
            this.rbtnUser_apply.Name = "rbtnUser_apply";
            this.rbtnUser_apply.Size = new System.Drawing.Size(84, 24);
            this.rbtnUser_apply.TabIndex = 53;
            this.rbtnUser_apply.Text = "USER";
            this.rbtnUser_apply.UseVisualStyleBackColor = true;
            this.rbtnUser_apply.CheckedChanged += new System.EventHandler(this.rbtnUser_apply_CheckedChanged);
            // 
            // rbtnSite_apply
            // 
            this.rbtnSite_apply.AutoSize = true;
            this.rbtnSite_apply.Location = new System.Drawing.Point(6, 29);
            this.rbtnSite_apply.Name = "rbtnSite_apply";
            this.rbtnSite_apply.Size = new System.Drawing.Size(74, 24);
            this.rbtnSite_apply.TabIndex = 52;
            this.rbtnSite_apply.Text = "SITE";
            this.rbtnSite_apply.UseVisualStyleBackColor = true;
            this.rbtnSite_apply.CheckedChanged += new System.EventHandler(this.rbtnSite_apply_CheckedChanged);
            // 
            // lbImagesToApply_apply
            // 
            this.lbImagesToApply_apply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lbImagesToApply_apply.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lbImagesToApply_apply.FormattingEnabled = true;
            this.lbImagesToApply_apply.ItemHeight = 20;
            this.lbImagesToApply_apply.Location = new System.Drawing.Point(10, 274);
            this.lbImagesToApply_apply.Name = "lbImagesToApply_apply";
            this.lbImagesToApply_apply.Size = new System.Drawing.Size(608, 224);
            this.lbImagesToApply_apply.TabIndex = 43;
            // 
            // lbImagesServer_apply
            // 
            this.lbImagesServer_apply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lbImagesServer_apply.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lbImagesServer_apply.FormattingEnabled = true;
            this.lbImagesServer_apply.ItemHeight = 20;
            this.lbImagesServer_apply.Location = new System.Drawing.Point(10, 54);
            this.lbImagesServer_apply.Name = "lbImagesServer_apply";
            this.lbImagesServer_apply.Size = new System.Drawing.Size(608, 164);
            this.lbImagesServer_apply.TabIndex = 42;
            this.lbImagesServer_apply.SelectedIndexChanged += new System.EventHandler(this.lbImagesServer_apply_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.label13.Location = new System.Drawing.Point(8, 254);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(49, 17);
            this.label13.TabIndex = 41;
            this.label13.Text = "Step 2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.label12.Location = new System.Drawing.Point(8, 31);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 17);
            this.label12.TabIndex = 40;
            this.label12.Text = "Step 1";
            // 
            // btnApply_apply
            // 
            this.btnApply_apply.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnApply_apply.FlatAppearance.BorderSize = 0;
            this.btnApply_apply.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnApply_apply.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnApply_apply.Location = new System.Drawing.Point(468, 512);
            this.btnApply_apply.Name = "btnApply_apply";
            this.btnApply_apply.Size = new System.Drawing.Size(150, 69);
            this.btnApply_apply.TabIndex = 39;
            this.btnApply_apply.Text = "APPLY";
            this.btnApply_apply.UseVisualStyleBackColor = false;
            this.btnApply_apply.Click += new System.EventHandler(this.btnApply_apply_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label11.Location = new System.Drawing.Point(64, 251);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(150, 20);
            this.label11.TabIndex = 37;
            this.label11.Text = "SELECT IMAGE:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label10.Location = new System.Drawing.Point(64, 31);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(510, 20);
            this.label10.TabIndex = 29;
            this.label10.Text = "PLEASE LOCATE THE IMAGE FILE YOU WISH TO APPLY:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage3.Controls.Add(this.lblEstimatedTime);
            this.tabPage3.Controls.Add(this.lblProgress);
            this.tabPage3.Controls.Add(this.lblCountFiles);
            this.tabPage3.Controls.Add(this.btnAbortWimgapi);
            this.tabPage3.Controls.Add(this.lblFilesInfo);
            this.tabPage3.Controls.Add(this.btnCaptureWimGapi);
            this.tabPage3.Controls.Add(this.btnCaptureImageX);
            this.tabPage3.Controls.Add(this.btnCapture_Refresh);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Controls.Add(this.lvFilesView_capture);
            this.tabPage3.Controls.Add(this.btnCapture_capture);
            this.tabPage3.Controls.Add(this.txtImageName_capture);
            this.tabPage3.Controls.Add(this.lbSaveImage_capture);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.lvPartition_capture);
            this.tabPage3.Controls.Add(this.lvDescription_capture);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1670, 742);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Capture image";
            // 
            // lblCountFiles
            // 
            this.lblCountFiles.AutoSize = true;
            this.lblCountFiles.BackColor = System.Drawing.Color.Transparent;
            this.lblCountFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCountFiles.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblCountFiles.Location = new System.Drawing.Point(635, 602);
            this.lblCountFiles.Name = "lblCountFiles";
            this.lblCountFiles.Size = new System.Drawing.Size(86, 17);
            this.lblCountFiles.TabIndex = 61;
            this.lblCountFiles.Text = "Count Files :";
            // 
            // btnAbortWimgapi
            // 
            this.btnAbortWimgapi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnAbortWimgapi.FlatAppearance.BorderSize = 0;
            this.btnAbortWimgapi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAbortWimgapi.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnAbortWimgapi.Location = new System.Drawing.Point(944, 521);
            this.btnAbortWimgapi.Name = "btnAbortWimgapi";
            this.btnAbortWimgapi.Size = new System.Drawing.Size(126, 36);
            this.btnAbortWimgapi.TabIndex = 60;
            this.btnAbortWimgapi.Text = "ABORT";
            this.btnAbortWimgapi.UseVisualStyleBackColor = false;
            this.btnAbortWimgapi.Click += new System.EventHandler(this.btnAbortWimgapi_Click);
            // 
            // lblFilesInfo
            // 
            this.lblFilesInfo.AutoSize = true;
            this.lblFilesInfo.BackColor = System.Drawing.Color.Transparent;
            this.lblFilesInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilesInfo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblFilesInfo.Location = new System.Drawing.Point(635, 573);
            this.lblFilesInfo.Name = "lblFilesInfo";
            this.lblFilesInfo.Size = new System.Drawing.Size(41, 17);
            this.lblFilesInfo.TabIndex = 58;
            this.lblFilesInfo.Text = "Files:";
            // 
            // btnCaptureWimGapi
            // 
            this.btnCaptureWimGapi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnCaptureWimGapi.FlatAppearance.BorderSize = 0;
            this.btnCaptureWimGapi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaptureWimGapi.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnCaptureWimGapi.Location = new System.Drawing.Point(638, 521);
            this.btnCaptureWimGapi.Name = "btnCaptureWimGapi";
            this.btnCaptureWimGapi.Size = new System.Drawing.Size(300, 39);
            this.btnCaptureWimGapi.TabIndex = 59;
            this.btnCaptureWimGapi.Text = "CAPTURE WIMGAPI";
            this.btnCaptureWimGapi.UseVisualStyleBackColor = false;
            this.btnCaptureWimGapi.Click += new System.EventHandler(this.btnCaptureWimGapi_Click);
            // 
            // btnCaptureImageX
            // 
            this.btnCaptureImageX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnCaptureImageX.FlatAppearance.BorderSize = 0;
            this.btnCaptureImageX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCaptureImageX.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnCaptureImageX.Location = new System.Drawing.Point(338, 629);
            this.btnCaptureImageX.Name = "btnCaptureImageX";
            this.btnCaptureImageX.Size = new System.Drawing.Size(160, 69);
            this.btnCaptureImageX.TabIndex = 57;
            this.btnCaptureImageX.Text = "CAPTURE IMAGEX";
            this.btnCaptureImageX.UseVisualStyleBackColor = false;
            this.btnCaptureImageX.Click += new System.EventHandler(this.btnCaptureImageX_Click);
            // 
            // btnCapture_Refresh
            // 
            this.btnCapture_Refresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnCapture_Refresh.FlatAppearance.BorderSize = 0;
            this.btnCapture_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCapture_Refresh.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnCapture_Refresh.Location = new System.Drawing.Point(21, 629);
            this.btnCapture_Refresh.Name = "btnCapture_Refresh";
            this.btnCapture_Refresh.Size = new System.Drawing.Size(150, 69);
            this.btnCapture_Refresh.TabIndex = 56;
            this.btnCapture_Refresh.Text = "REFRESH";
            this.btnCapture_Refresh.UseVisualStyleBackColor = false;
            this.btnCapture_Refresh.Click += new System.EventHandler(this.btnCapture_Refresh_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.label19.Location = new System.Drawing.Point(8, 540);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(49, 17);
            this.label19.TabIndex = 55;
            this.label19.Text = "Step 3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label18.Location = new System.Drawing.Point(64, 540);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(372, 20);
            this.label18.TabIndex = 54;
            this.label18.Text = "ENTER FILENAME FOR THE NEW IMAGE:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.rbtnFactory_capture);
            this.groupBox3.Controls.Add(this.rbtnUser_catpure);
            this.groupBox3.Controls.Add(this.rbtnSite_capture);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox3.Location = new System.Drawing.Point(627, 18);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(314, 74);
            this.groupBox3.TabIndex = 53;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Capture mode:";
            // 
            // rbtnFactory_capture
            // 
            this.rbtnFactory_capture.AutoSize = true;
            this.rbtnFactory_capture.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbtnFactory_capture.Location = new System.Drawing.Point(168, 29);
            this.rbtnFactory_capture.Name = "rbtnFactory_capture";
            this.rbtnFactory_capture.Size = new System.Drawing.Size(117, 24);
            this.rbtnFactory_capture.TabIndex = 54;
            this.rbtnFactory_capture.Text = "FACTORY";
            this.rbtnFactory_capture.UseVisualStyleBackColor = true;
            this.rbtnFactory_capture.CheckedChanged += new System.EventHandler(this.rbtnFactory_capture_CheckedChanged);
            // 
            // rbtnUser_catpure
            // 
            this.rbtnUser_catpure.AutoSize = true;
            this.rbtnUser_catpure.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbtnUser_catpure.Location = new System.Drawing.Point(82, 29);
            this.rbtnUser_catpure.Name = "rbtnUser_catpure";
            this.rbtnUser_catpure.Size = new System.Drawing.Size(84, 24);
            this.rbtnUser_catpure.TabIndex = 53;
            this.rbtnUser_catpure.Text = "USER";
            this.rbtnUser_catpure.UseVisualStyleBackColor = true;
            this.rbtnUser_catpure.CheckedChanged += new System.EventHandler(this.rbtnUser_catpure_CheckedChanged);
            // 
            // rbtnSite_capture
            // 
            this.rbtnSite_capture.AutoSize = true;
            this.rbtnSite_capture.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.rbtnSite_capture.Location = new System.Drawing.Point(6, 29);
            this.rbtnSite_capture.Name = "rbtnSite_capture";
            this.rbtnSite_capture.Size = new System.Drawing.Size(74, 24);
            this.rbtnSite_capture.TabIndex = 52;
            this.rbtnSite_capture.Text = "SITE";
            this.rbtnSite_capture.UseVisualStyleBackColor = true;
            this.rbtnSite_capture.CheckedChanged += new System.EventHandler(this.rbtnSite_capture_CheckedChanged);
            // 
            // lvFilesView_capture
            // 
            this.lvFilesView_capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lvFilesView_capture.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lvFilesView_capture.Location = new System.Drawing.Point(550, 274);
            this.lvFilesView_capture.Name = "lvFilesView_capture";
            this.lvFilesView_capture.Size = new System.Drawing.Size(520, 224);
            this.lvFilesView_capture.TabIndex = 51;
            this.lvFilesView_capture.UseCompatibleStateImageBehavior = false;
            this.lvFilesView_capture.SelectedIndexChanged += new System.EventHandler(this.lvFilesView_capture_SelectedIndexChanged);
            this.lvFilesView_capture.Click += new System.EventHandler(this.lvFilesView_capture_Click);
            this.lvFilesView_capture.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lvFilesView_capture_KeyDown);
            // 
            // btnCapture_capture
            // 
            this.btnCapture_capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnCapture_capture.FlatAppearance.BorderSize = 0;
            this.btnCapture_capture.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCapture_capture.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.btnCapture_capture.Location = new System.Drawing.Point(180, 629);
            this.btnCapture_capture.Name = "btnCapture_capture";
            this.btnCapture_capture.Size = new System.Drawing.Size(150, 69);
            this.btnCapture_capture.TabIndex = 50;
            this.btnCapture_capture.Text = "CAPTURE";
            this.btnCapture_capture.UseVisualStyleBackColor = false;
            this.btnCapture_capture.Click += new System.EventHandler(this.btnCapture_capture_Click);
            // 
            // txtImageName_capture
            // 
            this.txtImageName_capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtImageName_capture.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtImageName_capture.Location = new System.Drawing.Point(68, 577);
            this.txtImageName_capture.Name = "txtImageName_capture";
            this.txtImageName_capture.Size = new System.Drawing.Size(529, 26);
            this.txtImageName_capture.TabIndex = 49;
            this.txtImageName_capture.Text = "example.wim";
            // 
            // lbSaveImage_capture
            // 
            this.lbSaveImage_capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lbSaveImage_capture.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lbSaveImage_capture.FormattingEnabled = true;
            this.lbSaveImage_capture.ItemHeight = 20;
            this.lbSaveImage_capture.Location = new System.Drawing.Point(10, 274);
            this.lbSaveImage_capture.Name = "lbSaveImage_capture";
            this.lbSaveImage_capture.Size = new System.Drawing.Size(520, 224);
            this.lbSaveImage_capture.TabIndex = 48;
            this.lbSaveImage_capture.SelectedIndexChanged += new System.EventHandler(this.lbSaveImage_capture_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.label16.Location = new System.Drawing.Point(8, 246);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(49, 17);
            this.label16.TabIndex = 47;
            this.label16.Text = "Step 2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label17.Location = new System.Drawing.Point(64, 245);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(330, 20);
            this.label17.TabIndex = 46;
            this.label17.Text = "ENTER PATH FOR THE NEW IMAGE:";
            // 
            // lvPartition_capture
            // 
            this.lvPartition_capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lvPartition_capture.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lvPartition_capture.Location = new System.Drawing.Point(627, 103);
            this.lvPartition_capture.Name = "lvPartition_capture";
            this.lvPartition_capture.Size = new System.Drawing.Size(444, 136);
            this.lvPartition_capture.TabIndex = 45;
            this.lvPartition_capture.UseCompatibleStateImageBehavior = false;
            // 
            // lvDescription_capture
            // 
            this.lvDescription_capture.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.lvDescription_capture.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lvDescription_capture.FullRowSelect = true;
            this.lvDescription_capture.Location = new System.Drawing.Point(10, 52);
            this.lvDescription_capture.Name = "lvDescription_capture";
            this.lvDescription_capture.Size = new System.Drawing.Size(600, 136);
            this.lvDescription_capture.TabIndex = 44;
            this.lvDescription_capture.UseCompatibleStateImageBehavior = false;
            this.lvDescription_capture.SelectedIndexChanged += new System.EventHandler(this.lvDescription_capture_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.label14.Location = new System.Drawing.Point(8, 25);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(49, 17);
            this.label14.TabIndex = 43;
            this.label14.Text = "Step 1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Location = new System.Drawing.Point(64, 23);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(301, 20);
            this.label15.TabIndex = 41;
            this.label15.Text = "SELECT THE DISK TO CAPTURE:";
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.tabPage1.Controls.Add(this.pBoxWaiting2);
            this.tabPage1.Controls.Add(this.pBoxWaiting1);
            this.tabPage1.Controls.Add(this.pBoxStatus);
            this.tabPage1.Controls.Add(this.lblResult);
            this.tabPage1.Controls.Add(this.label26);
            this.tabPage1.Controls.Add(this.panel16);
            this.tabPage1.Controls.Add(this.panel17);
            this.tabPage1.Controls.Add(this.panel18);
            this.tabPage1.Controls.Add(this.panel19);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.panel6);
            this.tabPage1.Controls.Add(this.panel8);
            this.tabPage1.Controls.Add(this.panel14);
            this.tabPage1.Controls.Add(this.panel15);
            this.tabPage1.Controls.Add(this.lblName);
            this.tabPage1.Controls.Add(this.lblID);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.lblImageName);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.panel13);
            this.tabPage1.Controls.Add(this.panel4);
            this.tabPage1.Controls.Add(this.panel12);
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.panel11);
            this.tabPage1.Controls.Add(this.panel10);
            this.tabPage1.Controls.Add(this.lblSN);
            this.tabPage1.Controls.Add(this.lblMC);
            this.tabPage1.Controls.Add(this.lblClass);
            this.tabPage1.Controls.Add(this.lblTracer);
            this.tabPage1.Controls.Add(this.btnTestImage_sscos);
            this.tabPage1.Controls.Add(this.btnCustomOS_sscos);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(0);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1670, 742);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ATMs & SSCOs";
            // 
            // pBoxWaiting2
            // 
            this.pBoxWaiting2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pBoxWaiting2.BackColor = System.Drawing.Color.Transparent;
            this.pBoxWaiting2.Image = global::ImagesServer_v3._0.Properties.Resources.loading;
            this.pBoxWaiting2.Location = new System.Drawing.Point(1448, 651);
            this.pBoxWaiting2.Name = "pBoxWaiting2";
            this.pBoxWaiting2.Size = new System.Drawing.Size(45, 45);
            this.pBoxWaiting2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBoxWaiting2.TabIndex = 66;
            this.pBoxWaiting2.TabStop = false;
            this.pBoxWaiting2.Visible = false;
            // 
            // pBoxWaiting1
            // 
            this.pBoxWaiting1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pBoxWaiting1.BackColor = System.Drawing.Color.Transparent;
            this.pBoxWaiting1.Image = global::ImagesServer_v3._0.Properties.Resources.loading;
            this.pBoxWaiting1.Location = new System.Drawing.Point(183, 651);
            this.pBoxWaiting1.Name = "pBoxWaiting1";
            this.pBoxWaiting1.Size = new System.Drawing.Size(45, 45);
            this.pBoxWaiting1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBoxWaiting1.TabIndex = 65;
            this.pBoxWaiting1.TabStop = false;
            this.pBoxWaiting1.Visible = false;
            // 
            // pBoxStatus
            // 
            this.pBoxStatus.Image = global::ImagesServer_v3._0.Properties.Resources.GoodMark;
            this.pBoxStatus.Location = new System.Drawing.Point(870, 197);
            this.pBoxStatus.Name = "pBoxStatus";
            this.pBoxStatus.Size = new System.Drawing.Size(148, 134);
            this.pBoxStatus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBoxStatus.TabIndex = 64;
            this.pBoxStatus.TabStop = false;
            this.pBoxStatus.Visible = false;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResult.Location = new System.Drawing.Point(46, 257);
            this.lblResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(0, 32);
            this.lblResult.TabIndex = 63;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label26.Location = new System.Drawing.Point(28, 209);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(117, 20);
            this.label26.TabIndex = 62;
            this.label26.Text = "RESULTADO:";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel16.Location = new System.Drawing.Point(854, 195);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(10, 135);
            this.panel16.TabIndex = 61;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel17.Location = new System.Drawing.Point(10, 325);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(850, 9);
            this.panel17.TabIndex = 59;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel18.Location = new System.Drawing.Point(10, 197);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(10, 134);
            this.panel18.TabIndex = 60;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel19.Location = new System.Drawing.Point(10, 195);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(850, 9);
            this.panel19.TabIndex = 58;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button2.Location = new System.Drawing.Point(1422, 440);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(238, 82);
            this.button2.TabIndex = 57;
            this.button2.Text = "REBOOT";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label24.Location = new System.Drawing.Point(526, 29);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(138, 20);
            this.label24.TabIndex = 56;
            this.label24.Text = "EMPLOYE INFO:";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel6.Location = new System.Drawing.Point(980, 17);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(10, 78);
            this.panel6.TabIndex = 55;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel8.Controls.Add(this.panel9);
            this.panel8.Location = new System.Drawing.Point(512, 88);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(476, 9);
            this.panel8.TabIndex = 53;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel9.Location = new System.Drawing.Point(0, -37);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(476, 9);
            this.panel9.TabIndex = 37;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel14.Location = new System.Drawing.Point(512, 18);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(10, 72);
            this.panel14.TabIndex = 54;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel15.Location = new System.Drawing.Point(512, 17);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(476, 9);
            this.panel15.TabIndex = 52;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblName.Location = new System.Drawing.Point(672, 62);
            this.lblName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(62, 20);
            this.lblName.TabIndex = 51;
            this.lblName.Text = "NAME:";
            // 
            // lblID
            // 
            this.lblID.AutoSize = true;
            this.lblID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblID.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblID.Location = new System.Drawing.Point(672, 29);
            this.lblID.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblID.Name = "lblID";
            this.lblID.Size = new System.Drawing.Size(45, 20);
            this.lblID.TabIndex = 48;
            this.lblID.Text = "#ID :";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label23.Location = new System.Drawing.Point(8, 388);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(82, 20);
            this.label23.TabIndex = 47;
            this.label23.Text = "INSTALL:";
            // 
            // lblImageName
            // 
            this.lblImageName.AutoSize = true;
            this.lblImageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblImageName.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblImageName.Location = new System.Drawing.Point(146, 138);
            this.lblImageName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblImageName.Name = "lblImageName";
            this.lblImageName.Size = new System.Drawing.Size(67, 20);
            this.lblImageName.TabIndex = 44;
            this.lblImageName.Text = "IMAGE:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label21.Location = new System.Drawing.Point(27, 138);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(111, 20);
            this.label21.TabIndex = 43;
            this.label21.Text = "IMAGE INFO:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel2.Location = new System.Drawing.Point(844, 125);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(10, 48);
            this.panel2.TabIndex = 42;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel3.Location = new System.Drawing.Point(10, 165);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(842, 9);
            this.panel3.TabIndex = 40;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel13.Location = new System.Drawing.Point(478, 17);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(10, 85);
            this.panel13.TabIndex = 38;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel4.Location = new System.Drawing.Point(10, 126);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(10, 49);
            this.panel4.TabIndex = 41;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel12.Controls.Add(this.panel7);
            this.panel12.Location = new System.Drawing.Point(10, 95);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(476, 9);
            this.panel12.TabIndex = 36;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel7.Location = new System.Drawing.Point(0, -22);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(476, 9);
            this.panel7.TabIndex = 37;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel5.Location = new System.Drawing.Point(10, 125);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(840, 9);
            this.panel5.TabIndex = 39;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel11.Location = new System.Drawing.Point(10, 18);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(10, 89);
            this.panel11.TabIndex = 37;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.panel10.Location = new System.Drawing.Point(10, 17);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(476, 9);
            this.panel10.TabIndex = 35;
            // 
            // lblSN
            // 
            this.lblSN.AutoSize = true;
            this.lblSN.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSN.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblSN.Location = new System.Drawing.Point(26, 68);
            this.lblSN.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSN.Name = "lblSN";
            this.lblSN.Size = new System.Drawing.Size(151, 20);
            this.lblSN.TabIndex = 34;
            this.lblSN.Text = "SERIAL NUMBER:";
            // 
            // lblMC
            // 
            this.lblMC.AutoSize = true;
            this.lblMC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMC.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblMC.Location = new System.Drawing.Point(285, 68);
            this.lblMC.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMC.Name = "lblMC";
            this.lblMC.Size = new System.Drawing.Size(40, 20);
            this.lblMC.TabIndex = 33;
            this.lblMC.Text = "MC:";
            // 
            // lblClass
            // 
            this.lblClass.AutoSize = true;
            this.lblClass.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClass.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblClass.Location = new System.Drawing.Point(285, 35);
            this.lblClass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblClass.Name = "lblClass";
            this.lblClass.Size = new System.Drawing.Size(69, 20);
            this.lblClass.TabIndex = 32;
            this.lblClass.Text = "CLASS:";
            // 
            // lblTracer
            // 
            this.lblTracer.AutoSize = true;
            this.lblTracer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTracer.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblTracer.Location = new System.Drawing.Point(27, 35);
            this.lblTracer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTracer.Name = "lblTracer";
            this.lblTracer.Size = new System.Drawing.Size(82, 20);
            this.lblTracer.TabIndex = 31;
            this.lblTracer.Text = "TRACER:";
            // 
            // btnTestImage_sscos
            // 
            this.btnTestImage_sscos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnTestImage_sscos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTestImage_sscos.FlatAppearance.BorderSize = 0;
            this.btnTestImage_sscos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTestImage_sscos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTestImage_sscos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTestImage_sscos.Location = new System.Drawing.Point(6, 528);
            this.btnTestImage_sscos.Name = "btnTestImage_sscos";
            this.btnTestImage_sscos.Size = new System.Drawing.Size(400, 200);
            this.btnTestImage_sscos.TabIndex = 1;
            this.btnTestImage_sscos.Text = "TEST IMAGE";
            this.btnTestImage_sscos.UseVisualStyleBackColor = false;
            this.btnTestImage_sscos.Click += new System.EventHandler(this.btnTestImage_sscos_Click);
            // 
            // btnCustomOS_sscos
            // 
            this.btnCustomOS_sscos.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCustomOS_sscos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnCustomOS_sscos.FlatAppearance.BorderSize = 0;
            this.btnCustomOS_sscos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustomOS_sscos.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomOS_sscos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnCustomOS_sscos.Location = new System.Drawing.Point(1262, 528);
            this.btnCustomOS_sscos.Name = "btnCustomOS_sscos";
            this.btnCustomOS_sscos.Size = new System.Drawing.Size(400, 200);
            this.btnCustomOS_sscos.TabIndex = 0;
            this.btnCustomOS_sscos.Text = "CUSTOM OS";
            this.btnCustomOS_sscos.UseVisualStyleBackColor = false;
            this.btnCustomOS_sscos.Click += new System.EventHandler(this.btnCustomOS_sscos_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.tabControl1.Location = new System.Drawing.Point(-2, 123);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(0, 0);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1678, 775);
            this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl1.TabIndex = 13;
            // 
            // txtSlotInfo
            // 
            this.txtSlotInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.txtSlotInfo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtSlotInfo.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtSlotInfo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.txtSlotInfo.Location = new System.Drawing.Point(0, 0);
            this.txtSlotInfo.Name = "txtSlotInfo";
            this.txtSlotInfo.ReadOnly = true;
            this.txtSlotInfo.Size = new System.Drawing.Size(328, 19);
            this.txtSlotInfo.TabIndex = 15;
            this.txtSlotInfo.Text = "SLOT INFO:";
            // 
            // btnTab1
            // 
            this.btnTab1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTab1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTab1.FlatAppearance.BorderSize = 0;
            this.btnTab1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTab1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTab1.Location = new System.Drawing.Point(1052, 60);
            this.btnTab1.Name = "btnTab1";
            this.btnTab1.Size = new System.Drawing.Size(150, 69);
            this.btnTab1.TabIndex = 51;
            this.btnTab1.Text = "ATM-SSCO";
            this.btnTab1.UseVisualStyleBackColor = false;
            this.btnTab1.Click += new System.EventHandler(this.btnTab1_Click);
            // 
            // btnTab2
            // 
            this.btnTab2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTab2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTab2.FlatAppearance.BorderSize = 0;
            this.btnTab2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTab2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTab2.Location = new System.Drawing.Point(1208, 60);
            this.btnTab2.Name = "btnTab2";
            this.btnTab2.Size = new System.Drawing.Size(150, 69);
            this.btnTab2.TabIndex = 52;
            this.btnTab2.Text = "CAPTURE";
            this.btnTab2.UseVisualStyleBackColor = false;
            this.btnTab2.Click += new System.EventHandler(this.btnTab2_Click);
            // 
            // btnTab3
            // 
            this.btnTab3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTab3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTab3.FlatAppearance.BorderSize = 0;
            this.btnTab3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTab3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTab3.Location = new System.Drawing.Point(1364, 60);
            this.btnTab3.Name = "btnTab3";
            this.btnTab3.Size = new System.Drawing.Size(150, 69);
            this.btnTab3.TabIndex = 53;
            this.btnTab3.Text = "APPLY ";
            this.btnTab3.UseVisualStyleBackColor = false;
            this.btnTab3.Click += new System.EventHandler(this.btnTab3_Click);
            // 
            // btnTab4
            // 
            this.btnTab4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTab4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(35)))), ((int)(((byte)(45)))), ((int)(((byte)(54)))));
            this.btnTab4.FlatAppearance.BorderSize = 0;
            this.btnTab4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTab4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(173)))), ((int)(((byte)(157)))));
            this.btnTab4.Location = new System.Drawing.Point(1520, 60);
            this.btnTab4.Name = "btnTab4";
            this.btnTab4.Size = new System.Drawing.Size(150, 69);
            this.btnTab4.TabIndex = 54;
            this.btnTab4.Text = "NETWORK DRIVES";
            this.btnTab4.UseVisualStyleBackColor = false;
            this.btnTab4.Click += new System.EventHandler(this.btnTab4_Click);
            // 
            // lblProgress
            // 
            this.lblProgress.AutoSize = true;
            this.lblProgress.BackColor = System.Drawing.Color.Transparent;
            this.lblProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProgress.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblProgress.Location = new System.Drawing.Point(635, 633);
            this.lblProgress.Name = "lblProgress";
            this.lblProgress.Size = new System.Drawing.Size(73, 17);
            this.lblProgress.TabIndex = 62;
            this.lblProgress.Text = "Progress :";
            // 
            // lblEstimatedTime
            // 
            this.lblEstimatedTime.AutoSize = true;
            this.lblEstimatedTime.BackColor = System.Drawing.Color.Transparent;
            this.lblEstimatedTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstimatedTime.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.lblEstimatedTime.Location = new System.Drawing.Point(635, 666);
            this.lblEstimatedTime.Name = "lblEstimatedTime";
            this.lblEstimatedTime.Size = new System.Drawing.Size(184, 17);
            this.lblEstimatedTime.TabIndex = 63;
            this.lblEstimatedTime.Text = "Estimated Time Remaining :";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(29)))), ((int)(((byte)(37)))));
            this.ClientSize = new System.Drawing.Size(1676, 878);
            this.Controls.Add(this.btnTab4);
            this.Controls.Add(this.btnTab3);
            this.Controls.Add(this.btnTab2);
            this.Controls.Add(this.btnTab1);
            this.Controls.Add(this.txtSlotInfo);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lblVersion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "IMAGES SERVER v2.0";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxWaiting2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxWaiting1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pBoxStatus)).EndInit();
            this.panel8.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnMinimize;
        private System.Windows.Forms.Label lblVersion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.ListBox lbAllDrives_settings;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnRemoveDrive_settings;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbLetterToRemove_settings;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnMap_settings;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbDomain_settings;
        private System.Windows.Forms.TextBox txtPassword_settings;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUser_settings;
        private System.Windows.Forms.TextBox txtServer_settings;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbLetter_settings;
        private System.Windows.Forms.Button btnRefreshDrives_settings;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton rbtnFactory_apply;
        private System.Windows.Forms.RadioButton rbtnUser_apply;
        private System.Windows.Forms.RadioButton rbtnSite_apply;
        private System.Windows.Forms.ListBox lbImagesToApply_apply;
        private System.Windows.Forms.ListBox lbImagesServer_apply;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnApply_apply;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rbtnFactory_capture;
        private System.Windows.Forms.RadioButton rbtnUser_catpure;
        private System.Windows.Forms.RadioButton rbtnSite_capture;
        private System.Windows.Forms.ListView lvFilesView_capture;
        private System.Windows.Forms.Button btnCapture_capture;
        private System.Windows.Forms.TextBox txtImageName_capture;
        private System.Windows.Forms.ListBox lbSaveImage_capture;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ListView lvPartition_capture;
        private System.Windows.Forms.ListView lvDescription_capture;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.PictureBox pBoxStatus;
        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblID;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblImageName;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label lblSN;
        private System.Windows.Forms.Label lblMC;
        private System.Windows.Forms.Label lblClass;
        private System.Windows.Forms.Label lblTracer;
        private System.Windows.Forms.Button btnTestImage_sscos;
        private System.Windows.Forms.Button btnCustomOS_sscos;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.PictureBox pBoxWaiting1;
        private System.Windows.Forms.PictureBox pBoxWaiting2;
        private System.Windows.Forms.Button btnApply_Refresh;
        private System.Windows.Forms.Button btnCapture_Refresh;
        private System.Windows.Forms.TextBox txtSlotInfo;
        private System.Windows.Forms.Button btn_ImagexApply;
        private System.Windows.Forms.Button btnCaptureImageX;
        private System.Windows.Forms.Button btnTab1;
        private System.Windows.Forms.Button btnTab2;
        private System.Windows.Forms.Button btnTab3;
        private System.Windows.Forms.Button btnTab4;
        public System.Windows.Forms.Label lblFilesInfo;
        private System.Windows.Forms.Button btnCaptureWimGapi;
        private System.Windows.Forms.Button btnAbortWimgapi;
        public System.Windows.Forms.Label lblCountFiles;
        public System.Windows.Forms.Label lblProgress;
        public System.Windows.Forms.Label lblEstimatedTime;
    }
}

