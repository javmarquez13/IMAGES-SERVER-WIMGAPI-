﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImagesServer_v3._0
{
    public partial class AdminUser : Form
    {
        public AdminUser()
        {
            InitializeComponent();
            txtPassword.Focus();
        }

        private void AdminUser_Load(object sender, EventArgs e)
        {
            txtPassword.Focus();
        }

        private void btnPassword_Click(object sender, EventArgs e)
        {
          
            if (txtPassword.Text == "Admin2020")
            {
                DialogResult = DialogResult.OK;    
            }
            else
            {
                DialogResult = DialogResult.Abort;
            }
        }

        private void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                btnPassword_Click(sender, e);
            }
        }
    }
}
