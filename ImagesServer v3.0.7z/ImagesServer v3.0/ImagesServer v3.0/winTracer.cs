﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using GetSerialClassMC;
using LoadUser;

namespace ImagesServer_v3._0
{
    public partial class winTracer : Form
    {

        public string CLASS { get; set; }
        public string SERIALNUMBER { get; set; }
        public string MC { get; set; }
        public string TRACER { get; set; }

        public string IDNumber { get; set; }
        public string IDName { get; set; }
        public int SlotID { get; set; }

        GetSerialClassMC.GetSerialClassMC _UnitInfo = new GetSerialClassMC.GetSerialClassMC();
        LoadUser.LoadUser _LoadUser = new LoadUser.LoadUser();
        ConfigFiles _ConfigFiles = new ConfigFiles();
        string _userFile = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config Files\Users.ini";

        public winTracer()
        {
            InitializeComponent();
            txtTracer.Enabled = false;
            this.CLASS = null;
            this.SERIALNUMBER = null;
            this.MC = null;
            this.TRACER = null;
            this.IDNumber = null;
            this.IDName = null;
            this.SlotID = 0;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Abort;
        }

        private void txtEmployeNum_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                VerifyUserNT(txtEmployeNum.Text);                
            }
        }


        private void txtTracer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {               
                getUnitInfoFromIfactory(txtTracer.Text);
            }
        }


        void VerifyUserNT(string ID)
        {
            string _userResult = _ConfigFiles.reader("IMAGES_SERVER", ID, _userFile);

            if(_userResult == "")
            {
                txtEmployeNum.Clear();
                txtEmployeNum.Focus();
                lblError.Text = "El usuario es invalido...";
                return;
            }

            IDNumber = ID;
            IDName = _userResult;
            txtTracer.Enabled = true;
            txtTracer.Focus();
            _ControlActive = "txtTracer";
        }

        void getUnitInfoFromIfactory(string tracer)
        {
            if (!Regex.IsMatch(tracer, @"^\d{8}"))
            {
                txtTracer.Clear();
                txtTracer.Focus();
                lblError.Text = "El tracer es invalido...";
                return;
            }
            lblError.Text = "";
            string[] _result = _UnitInfo.GetSCMC(txtTracer.Text);

            if (_result[0] == "Serial Not Found")
            {
                txtTracer.Clear();
                txtTracer.Focus();
                lblError.Text = "El tracer es invalido...";
                return;
            }

            if (SlotID == 0 && !_result[1].Contains("66"))
            {
                txtTracer.Clear();
                txtTracer.Focus();
                lblError.Text = "Slot no seleccionado...";
                return;
            }

            SERIALNUMBER = _result[0];
            CLASS = _result[1];
            MC = _result[2];
            TRACER = tracer;         
            DialogResult = DialogResult.OK;
        }

        private void winTracer_Load(object sender, EventArgs e)
        {
            txtTracer.Focus();
        }



        //Slots
        private void slot1_Click(object sender, EventArgs e)
        {
            SlotID = 1;
            UserSelectSlot(SlotID);
        }

        private void slot2_Click(object sender, EventArgs e)
        {
            SlotID = 2;
            UserSelectSlot(SlotID);
        }

        private void slot3_Click(object sender, EventArgs e)
        {
            SlotID = 3;
            UserSelectSlot(SlotID);
        }

        private void Slot4_Click(object sender, EventArgs e)
        {
            SlotID = 4;
            UserSelectSlot(SlotID);
        }

        private void Slot5_Click(object sender, EventArgs e)
        {
            SlotID = 5;
            UserSelectSlot(SlotID);
        }

        private void Slot6_Click(object sender, EventArgs e)
        {
            SlotID = 6;
            UserSelectSlot(SlotID);
        }

        private void Slot7_Click(object sender, EventArgs e)
        {
            SlotID = 7;
            UserSelectSlot(SlotID);
        }

        private void Slot8_Click(object sender, EventArgs e)
        {
            SlotID = 8;
            UserSelectSlot(SlotID);
        }

        private void Slot9_Click(object sender, EventArgs e)
        {
            SlotID = 9;
            UserSelectSlot(SlotID);
        }

        private void Slot10_Click(object sender, EventArgs e)
        {
            SlotID = 10;
            UserSelectSlot(SlotID);
        }

        private void Slot11_Click(object sender, EventArgs e)
        {
            SlotID = 11;
            UserSelectSlot(SlotID);
        }

        private void Slot12_Click(object sender, EventArgs e)
        {
            SlotID = 12;
            UserSelectSlot(SlotID);
        }

        private void Slot13_Click(object sender, EventArgs e)
        {
            SlotID = 13;
            UserSelectSlot(SlotID);
        }

        private void Slot14_Click(object sender, EventArgs e)
        {
            SlotID = 14;
            UserSelectSlot(SlotID);
        }

        private void Slot15_Click(object sender, EventArgs e)
        {
            SlotID = 15;
            UserSelectSlot(SlotID);
        }

        private void Slot16_Click(object sender, EventArgs e)
        {
            SlotID = 16;
            UserSelectSlot(SlotID);
        }

        private void Slot17_Click(object sender, EventArgs e)
        {
            SlotID = 17;
            UserSelectSlot(SlotID);
        }

        private void Slot18_Click(object sender, EventArgs e)
        {
            SlotID = 18;
            UserSelectSlot(SlotID);
        }

        Color _colorDark = Color.FromArgb(16, 29, 37);
        void UserSelectSlot(int Slot)
        {
            if(Slot == 1)
            {
                slot1.BackColor = Color.LightGreen;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor = _colorDark;
                slot11.BackColor = _colorDark;
                slot12.BackColor = _colorDark;
                slot13.BackColor = _colorDark;
                slot14.BackColor = _colorDark;
                slot15.BackColor = _colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 2)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = Color.LightGreen;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor = _colorDark;
                slot11.BackColor = _colorDark;
                slot12.BackColor = _colorDark;
                slot13.BackColor = _colorDark;
                slot14.BackColor = _colorDark;
                slot15.BackColor = _colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 3)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = Color.LightGreen;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor =_colorDark;
            }

            if (Slot == 4)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = Color.LightGreen;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 5)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = Color.LightGreen;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 6)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = Color.LightGreen;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 7)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = Color.LightGreen;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 8)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = Color.LightGreen;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 9)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = Color.LightGreen;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 10)
            {
                slot1.BackColor =_colorDark;
                slot2.BackColor =_colorDark;
                slot3.BackColor =_colorDark;
                slot4.BackColor =_colorDark;
                slot5.BackColor =_colorDark;
                slot6.BackColor =_colorDark;
                slot7.BackColor =_colorDark;
                slot8.BackColor =_colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor = Color.LightGreen;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 11)
            {
                slot1.BackColor =_colorDark;
                slot2.BackColor =_colorDark;
                slot3.BackColor =_colorDark;
                slot4.BackColor =_colorDark;
                slot5.BackColor =_colorDark;
                slot6.BackColor =_colorDark;
                slot7.BackColor =_colorDark;
                slot8.BackColor =_colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor = _colorDark;
                slot11.BackColor = Color.LightGreen;
                slot12.BackColor = _colorDark;
                slot13.BackColor = _colorDark;
                slot14.BackColor = _colorDark;
                slot15.BackColor = _colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 12)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor = _colorDark;
                slot12.BackColor = Color.LightGreen;
                slot13.BackColor = _colorDark;
                slot14.BackColor = _colorDark;
                slot15.BackColor = _colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 13)
            {
                slot1.BackColor =_colorDark;
                slot2.BackColor =_colorDark;
                slot3.BackColor =_colorDark;
                slot4.BackColor =_colorDark;
                slot5.BackColor =_colorDark;
                slot6.BackColor =_colorDark;
                slot7.BackColor =_colorDark;
                slot8.BackColor =_colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor = _colorDark;
                slot11.BackColor = _colorDark;
                slot12.BackColor = _colorDark;
                slot13.BackColor = Color.LightGreen;
                slot14.BackColor = _colorDark;
                slot15.BackColor = _colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 14)
            {
                slot1.BackColor =_colorDark;
                slot2.BackColor =_colorDark;
                slot3.BackColor =_colorDark;
                slot4.BackColor =_colorDark;
                slot5.BackColor =_colorDark;
                slot6.BackColor =_colorDark;
                slot7.BackColor =_colorDark;
                slot8.BackColor =_colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor = _colorDark;
                slot11.BackColor = _colorDark;
                slot12.BackColor = _colorDark;
                slot13.BackColor = _colorDark;
                slot14.BackColor = Color.LightGreen;
                slot15.BackColor = _colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 15)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor = _colorDark;
                slot15.BackColor = Color.LightGreen;
                slot16.BackColor =_colorDark;
                slot17.BackColor =_colorDark;
                slot18.BackColor =_colorDark;
            }

            if (Slot == 16)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor = Color.LightGreen;
                slot17.BackColor = _colorDark;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 17)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor = _colorDark;
                slot17.BackColor = Color.LightGreen;
                slot18.BackColor = _colorDark;
            }

            if (Slot == 18)
            {
                slot1.BackColor = _colorDark;
                slot2.BackColor = _colorDark;
                slot3.BackColor = _colorDark;
                slot4.BackColor = _colorDark;
                slot5.BackColor = _colorDark;
                slot6.BackColor = _colorDark;
                slot7.BackColor = _colorDark;
                slot8.BackColor = _colorDark;
                slot9.BackColor = _colorDark;
                slot10.BackColor =_colorDark;
                slot11.BackColor =_colorDark;
                slot12.BackColor =_colorDark;
                slot13.BackColor =_colorDark;
                slot14.BackColor =_colorDark;
                slot15.BackColor =_colorDark;
                slot16.BackColor =_colorDark;
                slot17.BackColor = _colorDark;
                slot18.BackColor = Color.LightGreen;
            }
        }




        #region Teclado en pantalla

        string _ControlActive = "txtEmployeNum";

        private void btn1_Click(object sender, EventArgs e)
        {
            if(_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn1.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn1.Text);
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn2.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn2.Text);
            }
        }


        private void btn3_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn3.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn3.Text);
            }
        }


        private void btn4_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn4.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn4.Text);
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn5.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn5.Text);
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn6.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn6.Text);
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn7.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn7.Text);
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn8.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn8.Text);
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn9.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn9.Text);
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send("{ENTER}");
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send("{ENTER}");
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                SendKeys.Send(btn0.Text);
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                SendKeys.Send(btn0.Text);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            if (_ControlActive == "txtEmployeNum")
            {
                txtEmployeNum.Focus();
                txtEmployeNum.Clear();
            }

            if (_ControlActive == "txtTracer")
            {
                txtTracer.Focus();
                txtTracer.Clear();
            }

        }

        private void txtEmployeNum_Click(object sender, EventArgs e)
        {
            _ControlActive = "txtEmployeNum";
        }

        private void txtTracer_Click(object sender, EventArgs e)
        {
            _ControlActive = "txtTracer";
        }

        #endregion


    }
}
