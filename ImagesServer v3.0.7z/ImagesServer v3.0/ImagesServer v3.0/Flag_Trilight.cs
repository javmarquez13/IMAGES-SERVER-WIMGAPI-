﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace ImagesServer_v3._0
{
    class Flag_Trilight
    {
        public string _TRACER { get; set; }
        public DateTime _DATE { get; set; }
        public string _STEP { get; set; }
        public string _RESOURCE { get; set; }
        public string _PATH_TARS { get; set; }

        public Flag_Trilight()
        {
            _TRACER = _TRACER;
            _DATE = _DATE;
            _STEP = _STEP;
            _RESOURCE = _RESOURCE;
        }   
        
        public void SEND_TARS()
        {
            using (StreamWriter sw = File.CreateText(_PATH_TARS + _TRACER + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".txt"))
            {
                sw.WriteLine("TRACER=" +_TRACER);
                sw.WriteLine("DATE=" + _DATE.ToString());
                sw.WriteLine("STEP_NAME="+ _STEP);
                sw.WriteLine("RESOURCE=" + _RESOURCE);
                sw.Close();
            }
        }
    }
}
