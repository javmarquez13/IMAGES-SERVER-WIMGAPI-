﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using GetSerialClassMC;
using System.Diagnostics;
using System.Management;
using GetHistoryiFactory;
using System.Media;
using Microsoft.Win32;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;


using Microsoft.Wim;
using System.Xml;

namespace ImagesServer_v3._0
{
    /// <summary>
    /// FIRST RELEASE BY FRANCISCO MARQUEZ 
    /// IMAGES SERVER v2.0
    /// 
    /// 30 OCTUBRE 2019
    /// FIRST RELEASE
    /// 2.0.0.1
    /// 
    /// 31 OCTUBRE 2019
    /// Se agrega imagen pboxStatus para visualizar marca good y marca bad en la instalacion de custom os.
    /// 2.0.0.2
    /// 
    /// 31 OCTUBRE 2019
    /// Se agrega function para instalar imagen de atms desde el servidor.
    /// 2.0.0.3
    /// 
    /// 31 OCTUBRE 2019
    /// Se agrega numero de empleado en la segunda posicion al C:\jabil\unitinfo\file.txt
    /// 2.0.0.4
    /// 
    /// 01 NOVIEMBRE 2019
    /// Se omite verificacion de step en ifactory para ahorrar tiempo en linea de produccion.
    /// 2.0.0.5
    /// 
    /// 
    /// 01 NOVIEMBRE 2019
    /// Se agrega candado a la instalcion de iamgen de prueba pidiendo primero el pass de hipot antes de instalarse
    /// 2.0.0.6
    /// 
    /// 
    /// 04 NOVIEMBRE 2019
    /// Mostrar la informacion del empleado al instalar CUSTOM OS
    /// 2.0.0.7
    /// 
    /// 
    /// 04 NOVIEMBRE 2019
    /// Se agrega candado para que el operador no de varios click en btnInstallTestImage y btnInstallCustomOS con animacion
    /// 2.0.0.8
    /// 
    /// 
    /// 05 NOVIEMBRE 2019
    /// Se agrega variables SITE, USER y FACTORY para capturar y aplicar imagen
    /// 2.0.0.9
    /// 
    /// 
    /// 05 NOVIEMBRE 2019
    /// Se agrega boton de refresh en capture y apply "private void btnCapture_Refresh_Click(object sender, EventArgs e) FillListAllDisk();" 
    /// 2.0.1.0
    /// 
    /// 06 NOVIEMBRE 2019
    /// Se agerga nuevos nombres a las imagenes de ATMs para estandarizar.
    /// 2.0.1.1
    /// 
    /// 
    /// 06 NOVIEMBRE 2019
    /// Se agrega confiramcion de BIOS MODE para ATMs
    /// 2.0.1.2
    /// 
    /// 07 NOVIEMBRE 2019
    /// Candado para verificacion del registro BIOS_MODE UEFI PARA WINDOWS10 y LEGACY PARA WINDOWS7
    /// 2.0.1.3
    /// 
    /// 11 NOVIEMBRE 2019
    /// Strech Image para pBoxStatus
    /// 2.0.1.4
    /// 
    /// 15 NOVIEMBRE 2019
    /// Se cambia la ruta para descarga de imagnes a MXCHIM0PANGAEA02 atms
    /// 2.0.1.5
    /// 
    /// 19 NOVIEMBRE 2019
    /// Se cambia la ruta para descarga de imagnes a MXCHIM0PANGAEA02 en sscos
    /// 2.0.1.6
    /// 
    /// 19 NOVIEMBRE 2019
    /// Se eliminan espacios en log custom os cuando la unidad falla al instalar imagen
    /// 2.0.1.7
    /// 
    /// 20 NOVIEMBRE 2019
    /// En vaidacion imagen 7703W10_TESTIMAGE_v1.8.1_UAT.wim 20 de noviembre 2019
    /// 2.0.1.8
    /// 
    /// 22 NOVIEMBRE 2019
    /// Se elimina prompt antes de instalar imagen
    /// 2.0.1.9
    /// 
    /// 25 NOVIEMBRE 2019
    /// En vaidacion imagen 7360R6_TESTIMAGE_v1.8.1_UAT.wim 25 NOVIEMBRE 2019
    /// 2.0.2.0
    /// 
    /// 25 NOVIEMBRE 2019
    /// En vaidacion imagen 7350R6LITE_TESTIMAGE_v1.8.1_PROD.wim 25 NOVIEMBRE 2019
    /// *PangaeaDownloader 1.4.5
    /// *Pangaea 1.8.1.0
    /// 2.0.2.1
    /// 
    /// 26 NOVIEMBRE 2019
    /// Se agrega condicion para seleccionar imagen 7703 para la tarjeta richmond y la clase 7360 nuevo MC 7360MC1043 
    /// 2.0.2.2
    /// 
    /// 26 NOVIEMBRE 2019
    /// Release 7703W10_TESTIMAGE_v1.8.1_PROD.WIM, 7360R6_TESTIMAGE_v1.8.1_PROD.WIM en produccion
    /// 2.0.2.3
    /// 
    /// 02 DICIEMBRE 2019
    /// Release 7350R6LITE_TESTIMAGE_v1.8.1_PROD.wim en produccion
    /// 2.0.2.4
    /// 
    /// 03 DICIEMBRE 2019
    /// Funcion para crear file UnitInfo en prueba de Core
    /// 2.0.2.5
    /// 
    /// 05 DICIEMBRE 2019
    /// Archivo de configuracion de imagenes SetupTestImage.ini \\mxchim0pangea01\AUTOMATION_SSCO\IMAGES_SERVER_2.0\ConfigFile\SetupTestImages.ini
    /// Verificacion de step FVT antes de cargar test image
    /// 2.0.2.6
    ///
    /// 
    /// 20 DICIEMBRE 2019
    /// Funcion para reportar el status en semaforo TEST IMAGE
    /// 2.0.2.7
    /// 
    /// 26 DICIEMBRE 2019
    /// Funcion para reportar el status en semaforo CUSTOMER IMAGE
    /// 2.0.2.8
    /// 
    /// 
    /// 26 DICIEMBRE 2019
    /// Clase GetSlotByIp identifica la ip y proporciona el slot fisico de la UUT
    /// 2.0.2.9
    /// 
    /// 08 ENERO 2020
    /// Funcion en winTracer.cs para seleccionar slot en layout de sscos
    /// 2.0.3.0
    /// 
    /// 08 ENERO 2020
    /// Se agrega #Slot al file JABIL\UnitInfo\fileUnitInfo.txt
    /// 2.0.3.1
    /// 
    /// 09 ENERO 2020
    /// Modificacion de ReportingSemaphore se agrega columna de color
    /// 2.0.3.2
    /// 
    /// 09 ENERO 2020
    /// Se agrega clase y mc a .xml de RerpotingSemaphore
    /// 2.0.3.3
    /// 
    /// 10 ENERO 2020
    /// Se agrega condicion para la instalacionde imagen 7607_7703_Retail_Win10IoT_2019_v1809_64Bit_01.00.00.01.wim
    /// 2.0.3.4
    /// 
    /// 06 FEBRERO 2020
    /// Se agrega columan operador a el xml ReporingSemaphore
    /// 2.0.3.5
    /// 
    /// 11 FEBRERO 2020
    /// Se agrega columna progress a el xml ReporingSemaphore
    /// 2.0.3.6
    /// 
    /// 21 FEBRERO 2020
    /// Se agrega teclado numero en pantalla
    /// 2.0.3.7
    /// 
    /// 11 MARZO 2020
    /// Se migran imagenes de prueba ATMS a MXCHIM0PANGEA01
    /// 2.0.3.8
    /// 
    /// 11 MARZO 2020
    /// Funcion para capturar y aplicar imagenes sin utilerias de NCR
    /// 2.0.3.9
    /// 
    /// 25 MARZO 2020
    /// Verificar EJL antes de instalar TEST IMAGE para elimianr duplicados de prueba en unidades.
    /// 2.0.4.0
    /// 
    /// 27 ABRIL 2020
    /// Password para aplicar, capturar y mapear drives.
    /// 2.0.4.1
    /// 
    /// 07 MAYO 2020
    /// Se agrega nueva imagen MISANO
    /// 2.0.4.2
    /// 
    /// 26 JUNIO 2020
    /// Se agrega condicion para buscar disco hasta la letra J en custom os
    /// 2.0.4.3
    /// 
    /// 26 JUNIO 2020
    /// Se agrega condicion para nuevo mc con feature 7360-F120 WIN10IOT_64
    /// 2.0.4.4
    /// 
    /// 28 JUNIO 2020
    /// Se agrega condicion para nuevo feature P060 WIN7 10083193 validacion con ese tracer
    /// 2.0.4.5
    /// 
    /// 28 JUNIO 2020
    /// Se agrega condicion para validar configuracion de bios en windows 7 baseboard misano fix.
    /// 2.0.4.6
    /// 
    /// REMOVED
    /// 28 JUNIO 2020
    /// Se agrega candado para verificar que el display coincida con el tracer indicado. Richmond 7703.
    /// **********
    /// 
    /// 
    /// 13 OCTUBRE 2020
    /// Se agrega try catch para verificar error al final de la imagen
    /// 2.0.4.7
    /// 
    /// 
    /// 16 OCTUBRE 2020
    /// Se remueve rutina para reportar xmllog al sempaforo
    /// 2.0.4.8
    /// 
    /// 
    /// 03 NOVIEMBRE 2020
    /// Se remueve rutina para reportar xmllog al semaforo
    /// 2.0.4.9
    /// 
    /// 
    /// 04 NOVIEMBRE 2020
    /// Se modifica funcion para cargado de imagens de ATM 5801P100 WIN10, 5801P099 WIN07, 5801P060 WIN07
    /// 2.0.5.0
    /// 
    /// 
    /// 05 NOVIEMBRE 2020
    /// Se agrega feature 5801P999 WIN07
    /// 2.0.5.1
    /// 
    /// 
    /// 05 ENERO 2021
    /// Rutina para borrar directorio si este esta existente  line 709 if (DirInfo.Exists) DirInfo.Delete(true);
    /// 2.0.5.2
    /// 
    /// 
    /// 06 ENERO 2021
    /// Rutina para borrar directorio si este esta existente  line 709 if (DirInfo.Exists) DirInfo.Delete(true); FIX
    /// 2.0.5.3
    /// 
    /// 
    /// 24 FEBRERO 2021
    /// Se agrega clase para mandar tars a equipo triligth y empezar su contrtuccion.
    /// 2.0.5.4
    /// 
    /// </summary>
    /// 


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //label with the application version.
            lblVersion.Text = "v2.0.5.4";
        }

        #region Variables Globales
        string _RadsImage = @"X:\ImagingTools\RadsImageX.exe";
        string _ImageX = @"X:\windows\system32\ImageX.exe";
        string _bcdBoot = @"X:\windows\system32\bcdboot.exe";
        string _bootsect = @"X:\windows\system32\ImageX.exe";
        //string _ApplyArgStart = "/prompt /apply ";
        string _ApplyArgStart = "/apply ";
        //string _ApplyArgEnd = " Factory 0";
        string _ApplyArgEnd = " 0";
        string _CaptureArgsStart = "/capture ";
        int seconds = 5;

        string _tempSubFolder = "";
        string _tempServer = "";
        string _tempDrive = "";

        //Path to report logs CUSTOM OS
        string _LOG_DIR = @"\\MXCHIM0PANGEA01\SSCO_IMAGESlogs\";
        string _LOG_DIR_BK = @"\\MXCHIM0PANGEA01\SSCO_IMAGES\logs\Images\";

        //path for de features
        string _dirFeatures = @"\\mxchim0pangea01\diskbld\feats\";

        //Test images names for SSCOs
        string _TestImage7703 = "7703W10_TESTIMAGE_v1.8.1_PROD.wim"; //RELEASE PANGAEA 1.8.1
        string _TestImage7358 = "7358R6_TESTIMAGE_v1.8_PROD.wim";
        string _TestImage7360 = "7360R6_TESTIMAGE_v1.8.1_PROD.wim"; //RELEASE PANGAEA 1.8.1
        string _TestImage7362 = "7362R6_TESTIMAGE_v1.8_PROD.wim";
        string _TestImage7350R6L = "7350R6LITE_TESTIMAGE_v1.8.1_PROD.wim"; //RELEASE PANGAEA 1.8.1
        string _TestImage7350R5 = "7350R5_TESTIMAGE_v1.8_PROD.wim";


        //Test images names for sscos UAT
        string _TestImage7703UAT = "7703W10_TESTIMAGE_v1.8.1_UAT.wim";
        string _TestImage7360UAT = "7360R6_TESTIMAGE_v1.8.1_UAT.wim";

        //Test images name for ATMS
        string _TestImageEstoril_Windows7 = "ATM_ESTORIL_WIN7.wim";
        string _TestImageEstoril_Windows10 = "ATM_ESTORIL_WIN10.wim";
        string _TestImageMisano_Windows7 = "ATM_MISANO_WIN7.wim";
        string _TestImageMisano_Windows10 = "ATM_MISANO_WIN10.wim";


        //CustomOS images names:
        string _POSREADY7Skylake = "POS Ready 7 (32 Bit) XR7 Plus Compatible Skylake D370-1038-0100_01.00.00.02.wim";
        string _POS7_64bit = "POS7_64bit.wim";
        string _POSReady_2009 = "POSReady_2009.wim";
        string _POSReady7_32bit = "POSReady7_32bit.wim";
        string _WAL_R6LITE = "WAL_R6LITE.wim";
        string _Windows7ProfessionalEmbedded32Bit = "Windows 7 professional embedded 32 bit.wim";
        string _Windows10_UEFI_D370 = "Windows10_UEFI_D370-1066-0100_01.00.00.00.wim";
        string _XR7_XR6_Win10_IoT_64b_2016 = "XR7-XR6_Win10-IoT-64b-2016_D370-1066_01.00.00.00.wim";
        string _XR7_XR6_Win7_PRO_EMBEDDED_64b = "XR7-XR6-Win7_PRO_EMBEDDED_64b_D370-1061_01.00.00.05.wim";
        string _7607_7703_Retail_Win10IoT_2019 = "7607_7703_Retail_Win10IoT_2019_v1809_64Bit_01.00.00.01.wim";
        string _7702_7603_Retail_Win10IoT_2019 = "7702_7603_Retail_Win10IoT_2019_v1809_64bit_01.00.00.00.wim";


        //Letter for server MXCHIM0PANGEA01 & MXCHIM0PANGEA02
        string SSSCO_IMAGES = "W:";
        string ATM_IMAGES = "Z:";     //mxchim0pangea02
        //string ATM_IMAGES = "T:";   //mxchim0pangea01
        string AUTOMATION_SSCO = "Y:";

        //Letter for server MXCHIM0PANGEA02
        string SSSCO_IMAGES_02 = "R:";
        string ATM_IMAGES_02 = "Z:";

        GetSerialClassMC.GetSerialClassMC _UnitInfo = new GetSerialClassMC.GetSerialClassMC();
        GetHistoryiFactory.GetHistoryiFactory _UnitHistory = new GetHistoryiFactory.GetHistoryiFactory();
        ConfigFiles _ConfigFiles = new ConfigFiles();
        GetSlotByIP _GetSlotByIP = new GetSlotByIP();

        //PATH C:\JABIL\UNITINFO\
        string _dirUnitInfo = @":\JABIL\UnitInfo\";
        string _userFile = @"\\mxchim0pangea01\AUTOMATION_SSCO\Config Files\Users.ini";

        #endregion


        #region Slot information on validation
        string _localIpAdress = string.Empty;
        string _localSlot = string.Empty;
        int SlotID;

        void SlotInfo()
        {
            txtSlotInfo.Text = "SLOT INFO: " + " " + "#" + SlotID;
        }

        string GetLocalIPAddress()
        {
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    return ip.ToString();
                }
            }

            throw new Exception("No network adapters with an IPv4 address in the system!");
        }

        void ReportingSemaphore(string START_TIME, string OPERATOR, string TRACER, string CLASSMC, string SlotID, string STATUS, string COLOR, string PROGRESS)
        {
            Reporting _reporting = new Reporting();
            _reporting.XMLSSCO();
            string IP = GetLocalIPAddress();
            _reporting.CreateXML(START_TIME, OPERATOR, TRACER, CLASSMC, SlotID, IP, STATUS, COLOR, PROGRESS);
        }

        #endregion


        #region Eventos Aplicaion, inicializacion, general

        private void Form1_Load(object sender, EventArgs e)
        {
            tabControl1.DrawMode = TabDrawMode.OwnerDrawFixed;
            tabControl1.Region = new Region(new RectangleF(this.tabPage1.Left, this.tabPage1.Top, this.tabPage1.Width, this.tabPage1.Height));


            SlotInfo();
            SetupTestImage();

            //simulate click 
            btnRefreshDrives_settings_Click(sender, e);

            //initialize listviews
            initListViews();
            FillListAllDisk();

            //initialize settings capture mode  
            if (Properties.Settings.Default._captureMode == "Site")
            {
                rbtnSite_capture.Checked = true;
            }
            if (Properties.Settings.Default._captureMode == "User")
            {
                rbtnUser_catpure.Checked = true;
            }
            if (Properties.Settings.Default._captureMode == "Factory")
            {
                rbtnFactory_capture.Checked = true;
            }

            //initialize settings apply mode       
            if (Properties.Settings.Default._applyMode == "Site")
            {
                rbtnSite_apply.Checked = true;
            }
            if (Properties.Settings.Default._applyMode == "User")
            {
                rbtnUser_apply.Checked = true;
            }
            if (Properties.Settings.Default._applyMode == "Factory")
            {
                rbtnFactory_apply.Checked = true;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Application exit to close the application.
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            //Button to activate minimized mode
            this.WindowState = FormWindowState.Minimized;
        }

        #endregion


        #region TabPage ATMs & SSCOs

        //FUNCTION TO GET SERIAL NUMBER, MC NUMBER BY TRACER NUMBER
        Tuple<string, string, string, string, string, string, bool> UnitInfoFromIfactory()
        {
            DialogResult dr = new DialogResult();
            winTracer winTracer = new winTracer();
            string _Class = "";
            string _SerialNumber = "";
            string _McNumber = "";
            string _tracer = "";
            string _ID = "";
            string _Name = "";

            bool _flag = false;


            dr = winTracer.ShowDialog();
            this.Refresh();

            if (dr == DialogResult.OK)
            {
                _Class = winTracer.CLASS;
                _SerialNumber = winTracer.SERIALNUMBER;
                _McNumber = winTracer.MC;
                _tracer = winTracer.TRACER;
                _ID = winTracer.IDNumber;
                _Name = winTracer.IDName;
                SlotID = winTracer.SlotID;

                lblTracer.Text = "TRACER: " + _tracer;
                lblSN.Text = "SERIAL NUMBER: " + _SerialNumber;
                lblClass.Text = "CLASS: " + _Class;
                lblMC.Text = "MC: " + _McNumber;
                lblID.Text = "#ID: " + _ID;
                lblName.Text = "Name: " + _Name;

                _flag = true;
            }
            return Tuple.Create(_Class, _SerialNumber, _McNumber, _tracer, _ID, _Name, _flag);


        }

        //FUNCTION TO VERIFY STEP IN IFACTORY
        bool CheckStep(string SerialNumber, string StepToCheck)
        {
            int Loops = 1;
            int numSteps = 0;
            string STEP = "";
            string STATUS = "";
            string DATE = "";
            bool STEPVAL1 = false;
            DataSet ds;
            DataTable dt;

            try
            {
                ds = _UnitHistory.GetHistory(SerialNumber);
                dt = ds.Tables[0];
                numSteps = dt.Rows.Count;
                numSteps = numSteps - 1;

                while (Loops <= numSteps)
                {
                    var varDate = dt.Rows[Loops]["ArrivalTime"];
                    DATE = varDate.ToString();
                    var varStep = dt.Rows[Loops]["ProcessName"];
                    STEP = varStep.ToString();
                    var varStepStatus = dt.Rows[Loops]["ProcessResult"];
                    STATUS = varStepStatus.ToString();

                    if (STEP == StepToCheck && STATUS == "Passed") STEPVAL1 = true;
                    Loops = Loops + 1;
                    System.Threading.Thread.Sleep(50);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return STEPVAL1;
        }


        //FUNCION TO INSTAL TEST IMAGE FOR SSCOS
        void MainTestImageForSSCOsfunction()
        {
            string _class = "";
            string _serialNumber = "";
            string _mc = "";
            string _tracer = "";
            string _ID = "";
            string _Name = "";
            bool _flag = false;
            bool _flagCustomOS = false;
            int _result = 0;


            var items = UnitInfoFromIfactory();
            _class = items.Item1;
            _serialNumber = items.Item2;
            _mc = items.Item3;
            _tracer = items.Item4;
            _ID = items.Item5;
            _Name = items.Item6;
            _flag = items.Item7;


            var _items = getBuildType();
            string _mainDisk = _items.Item3;

            string _BaseBoard = getMotherBoardType();


            SlotInfo();

            //SEMAPHORE
            //ReportingSemaphore(DateTime.Now.ToString(), _ID + "-" + _Name, _tracer, _class + _mc, SlotID.ToString(), "Instalando Imagen prueba... " + DateTime.Now.ToString(), "YELLOW", "2%");

            if (!_flag) return;

            var _items2 = IsCompleteEJL(_mainDisk, _tracer);
            string _ejl = _items2.Item1;
            bool _isCompleteEjl = _items2.Item2;




            //if(_BaseBoard == "Richmond" && !items.Item1.Contains("7703"))
            //{
            //    MessageBox.Show("Unidad con Display equivocado " +"\n" +  "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            if (_isCompleteEjl)
            {
                MessageBox.Show("Unidad con log : " + _tracer + ".ejl" + " completo" + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (CheckStep(_serialNumber, "CUSTOM OS"))
            {
                MessageBox.Show("Unidad con PASS de CUSTOM OS" + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (CheckStep(_serialNumber, "FVT"))
            {
                MessageBox.Show("Unidad con PASS de FVT" + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!CheckStep(_serialNumber, "HIPOT"))
            {
                MessageBox.Show("Unidad sin PASS de HIPOT" + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }



            //install test image               //install test image          
            if (_BaseBoard == "Pocono" && _class == "7350")
            {
                lblImageName.Text = _TestImage7350R5;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _TestImage7350R5 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_BaseBoard == "Monaco" && _class == "7350")
            {
                lblImageName.Text = _TestImage7350R6L;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _TestImage7350R6L + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }
            if (_BaseBoard == "Monaco" && _class == "7358")
            {
                lblImageName.Text = _TestImage7358;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _TestImage7358 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_BaseBoard == "Richmond" && _class == "7358" || _BaseBoard == "Richmond" && _class == "7360")
            {
                lblImageName.Text = _TestImage7703;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _TestImage7703 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_BaseBoard == "Monaco" && _class == "7360")
            {
                lblImageName.Text = _TestImage7360;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _TestImage7360 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_BaseBoard == "Monaco" && _class == "7362")
            {
                lblImageName.Text = _TestImage7362;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _TestImage7362 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            OnError:
            {
                lblImageName.Text = "COMPATIBLE IMAGE NOT FOUND TO " + _BaseBoard.ToUpper() + " MOTHERBOARD";
                MessageBox.Show("NO SE HA ENCONTRADO IMAGEN DE PRUEBA PARA ESTA UNIDAD." + "\n" + "\n" + "\n" + "CONTACTA A INGENIERIA DE PRUEBAS!", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FoundIt:
            {

            }

            if (_result != 0)
            {
                MessageBox.Show(lblImageName.Text + " No ha sido instalada correctamente...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblResult.ForeColor = Color.Red;
                lblResult.Text = "TEST IMAGE: No ha sido instalada correctamente...";
                return;
            }
            if (_result == 0)
            {
                lblResult.ForeColor = Color.Green;
                lblResult.Text = "TEST IMAGE: Se instalo correctamente!";
            }


            try
            {
                //Create directory with UnitInfo.
                string _pathUnitInfo = "";
                string _pathUnitInfoA = @"A:\JABIL\";
                if (Directory.Exists(_pathUnitInfoA)) _pathUnitInfo = _pathUnitInfoA + @"UnitInfo\";
                string _pathUnitInfoB = @"B:\JABIL\";
                if (Directory.Exists(_pathUnitInfoB)) _pathUnitInfo = _pathUnitInfoB + @"UnitInfo\";
                string _pathUnitInfoC = @"C:\JABIL\";
                if (Directory.Exists(_pathUnitInfoC)) _pathUnitInfo = _pathUnitInfoC + @"UnitInfo\";
                string _pathUnitInfoD = @"D:\JABIL\";
                if (Directory.Exists(_pathUnitInfoD)) _pathUnitInfo = _pathUnitInfoD + @"UnitInfo\";
                string _pathUnitInfoE = @"E:\JABIL\";
                if (Directory.Exists(_pathUnitInfoE)) _pathUnitInfo = _pathUnitInfoE + @"UnitInfo\";
                string _pathUnitInfoF = @"F:\JABIL\";
                if (Directory.Exists(_pathUnitInfoF)) _pathUnitInfo = _pathUnitInfoF + @"UnitInfo\";
                string _pathUnitInfoG = @"G:\JABIL\";
                if (Directory.Exists(_pathUnitInfoG)) _pathUnitInfo = _pathUnitInfoG + @"UnitInfo\";
                string _pathUnitInfoH = @"H:\JABIL\";
                if (Directory.Exists(_pathUnitInfoH)) _pathUnitInfo = _pathUnitInfoH + @"UnitInfo\";
                string _pathUnitInfoI = @"I:\JABIL\";
                if (Directory.Exists(_pathUnitInfoI)) _pathUnitInfo = _pathUnitInfoI + @"UnitInfo\";
                string _pathUnitInfoJ = @"J:\JABIL\";
                if (Directory.Exists(_pathUnitInfoJ)) _pathUnitInfo = _pathUnitInfoJ + @"UnitInfo\";
                string _pathUnitInfoK = @"K:\JABIL\";
                if (Directory.Exists(_pathUnitInfoK)) _pathUnitInfo = _pathUnitInfoK + @"UnitInfo\";


                DirectoryInfo DirInfo = new DirectoryInfo(_pathUnitInfo);

                if (DirInfo.Exists)
                {
                    DirectoryInfo _dirFilesInfo = new DirectoryInfo(_pathUnitInfo);
                    FileInfo[] _files = _dirFilesInfo.GetFiles();
                    foreach (FileInfo _file in _files)
                    {
                        _file.Delete();
                    }

                }
                if (!DirInfo.Exists) DirInfo.Create();

                using (StreamWriter sw = File.CreateText(_pathUnitInfo + _tracer + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".txt"))
                {
                    sw.WriteLine(_tracer);
                    sw.WriteLine(_ID);
                    sw.WriteLine(_Name);
                    sw.WriteLine(SlotID);
                    sw.Close();
                }

                //reboot
                Process.Start("shutdown.exe", "-r -t 6");
                timer1.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //FUNCTION TO INSTALL TEST IMAGE FOR ATMS
        void MainTestImageForATMsfunction()
        {
            string _class = "";
            string _serialNumber = "";
            string _mc = "";
            string _tracer = "";
            string _ID = "";
            string _Name = "";
            string _OS = "";
            bool _flag = false;
            int _result = 0;
            string _BaseBoard = string.Empty;
            bool _MisanoFeature = false;

            var items = UnitInfoFromIfactory();
            _class = items.Item1;
            _serialNumber = items.Item2;
            _mc = items.Item3;
            _tracer = items.Item4;
            _ID = items.Item5;
            _Name = items.Item6;
            _flag = items.Item7;

            if (!_flag) return;

            _BaseBoard = getMotherBoardType(); //GETTING THE BASEBOARD TYPE


            var items2 = GetOS(_class, _mc);

            _OS = items2.Item1;
            _MisanoFeature = items2.Item2;


            if (_BaseBoard == "Estoril" && _OS == "WIN7")
            {
                RegistryKey key = Registry.LocalMachine.CreateSubKey(@"System\CurrentControlSet\Control"); //Function to review the BIOS CONFIGURATION 1=LEGACY 2=UEFI
                object value = key.GetValue("PEFirmwareType");
                key.Close();

                if (value.ToString() == "1")
                {
                    lblImageName.Text = _TestImageEstoril_Windows7;
                    _result = ApplyRadsImage(ATM_IMAGES + "\"" + _TestImageEstoril_Windows7 + "\"", "", Properties.Settings.Default._applyMode);
                    goto FoundIt;
                }
                else
                {
                    lblImageName.Text = _TestImageEstoril_Windows7;
                    MessageBox.Show("La configuracion del Bios no es la correcta!" + "\n" + "\n" + "CONFIGURACION ACTUAL: BIOS_MODE=UEFI" + "\n" + "\n" + "CONFIGURACION ESPERADA: BIOS_MODE=LEGACY", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblResult.ForeColor = Color.Red;
                    lblResult.Text = "TEST IMAGE: Revise configuracion: BIOS_MODE=LEGACY";
                    pBoxStatus.Visible = true;
                    pBoxStatus.Image = Properties.Resources.BadMark;
                    return;
                }
            }

            if (_BaseBoard == "Estoril" && _OS == "WIN10")
            {
                RegistryKey key = Registry.LocalMachine.CreateSubKey(@"System\CurrentControlSet\Control"); //Function to review the BIOS CONFIGURATION 1=LEGACY 2=UEFI
                object value = key.GetValue("PEFirmwareType");
                key.Close();

                if (value.ToString() == "2")
                {
                    lblImageName.Text = _TestImageEstoril_Windows10;
                    _result = ApplyRadsImage(ATM_IMAGES + "\"" + _TestImageEstoril_Windows10 + "\"", "", Properties.Settings.Default._applyMode);
                    goto FoundIt;
                }
                else
                {
                    lblImageName.Text = _TestImageEstoril_Windows10;
                    MessageBox.Show("La configuracion del Bios no es la correcta!" + "\n" + "\n" + "CONFIGURACION ACTUAL: BIOS_MODE=LEGACY" + "\n" + "\n" + "CONFIGURACION ESPERADA: BIOS_MODE=UEFI", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblResult.ForeColor = Color.Red;
                    lblResult.Text = "TEST IMAGE: Revise configuracion: BIOS_MODE=UEFI";
                    pBoxStatus.Visible = true;
                    pBoxStatus.Image = Properties.Resources.BadMark;
                    return;
                }
            }

            if (_BaseBoard == "Misano" && _OS == "WIN7" && _MisanoFeature)
            {
                RegistryKey key = Registry.LocalMachine.CreateSubKey(@"System\CurrentControlSet\Control"); //Function to review the BIOS CONFIGURATION 1=LEGACY 2=UEFI
                object value = key.GetValue("PEFirmwareType");
                key.Close();

                if (value.ToString() == "1")
                {
                    lblImageName.Text = _TestImageMisano_Windows7;
                    _result = ApplyRadsImage(ATM_IMAGES + "\"" + _TestImageMisano_Windows7 + "\"", "", Properties.Settings.Default._applyMode);
                    goto FoundIt;
                }
                else
                {
                    lblImageName.Text = _TestImageEstoril_Windows7;
                    MessageBox.Show("La configuracion del Bios no es la correcta!" + "\n" + "\n" + "CONFIGURACION ACTUAL: BIOS_MODE=UEFI" + "\n" + "\n" + "CONFIGURACION ESPERADA: BIOS_MODE=LEGACY", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblResult.ForeColor = Color.Red;
                    lblResult.Text = "TEST IMAGE: Revise configuracion: BIOS_MODE=LEGACY";
                    pBoxStatus.Visible = true;
                    pBoxStatus.Image = Properties.Resources.BadMark;
                    return;
                }
            }


            if (_BaseBoard == "Misano" && _OS == "WIN10" && _MisanoFeature)
            {
                RegistryKey key = Registry.LocalMachine.CreateSubKey(@"System\CurrentControlSet\Control"); //Function to review the BIOS CONFIGURATION 1=LEGACY 2=UEFI
                object value = key.GetValue("PEFirmwareType");
                key.Close();

                if (value.ToString() == "2")
                {
                    lblImageName.Text = _TestImageMisano_Windows10;
                    _result = ApplyRadsImage(ATM_IMAGES + "\"" + _TestImageMisano_Windows10 + "\"", "", Properties.Settings.Default._applyMode);
                    goto FoundIt;
                }
                else
                {
                    lblImageName.Text = _TestImageMisano_Windows10;
                    MessageBox.Show("La configuracion del Bios no es la correcta!" + "\n" + "\n" + "CONFIGURACION ACTUAL: BIOS_MODE=LEGACY" + "\n" + "\n" + "CONFIGURACION ESPERADA: BIOS_MODE=UEFI", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblResult.ForeColor = Color.Red;
                    lblResult.Text = "TEST IMAGE: Revise configuracion: BIOS_MODE=UEFI";
                    pBoxStatus.Visible = true;
                    pBoxStatus.Image = Properties.Resources.BadMark;
                    return;
                }
            }

            OnError:
            {
                lblImageName.Text = "COMPATIBLE IMAGE NOT FOUND TO " + _BaseBoard.ToUpper() + " MOTHERBOARD";
                MessageBox.Show("NO SE HA ENCONTRADO IMAGEN DE PRUEBA PARA ESTA UNIDAD." + "\n" + "\n" + "\n" + "CONTACTA A INGENIERIA DE PRUEBAS!", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FoundIt:
            {

            }

            if (_result != 0)
            {
                MessageBox.Show(lblImageName.Text + " No ha sido instalada correctamente...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblResult.ForeColor = Color.Red;
                lblResult.Text = "TEST IMAGE: No ha sido instalada correctamente...";
                pBoxStatus.Visible = true;
                pBoxStatus.Image = Properties.Resources.BadMark;
                return;
            }
            if (_result == 0)
            {
                lblResult.ForeColor = Color.Green;
                lblResult.Text = "TEST IMAGE: Se instalo correctamente!";
                pBoxStatus.Visible = true;
                pBoxStatus.Image = Properties.Resources.GoodMark;
            }

            //Create directory with UnitInfo.
            string _pathUnitInfo = "";
            string _pathUnitInfoA = @"A:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoA)) _pathUnitInfo = _pathUnitInfoA + @"UnitInfo\";
            string _pathUnitInfoB = @"B:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoB)) _pathUnitInfo = _pathUnitInfoB + @"UnitInfo\";
            string _pathUnitInfoC = @"C:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoC)) _pathUnitInfo = _pathUnitInfoC + @"UnitInfo\";
            string _pathUnitInfoD = @"D:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoD)) _pathUnitInfo = _pathUnitInfoD + @"UnitInfo\";
            string _pathUnitInfoE = @"E:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoE)) _pathUnitInfo = _pathUnitInfoE + @"UnitInfo\";
            string _pathUnitInfoF = @"F:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoF)) _pathUnitInfo = _pathUnitInfoF + @"UnitInfo\";
            string _pathUnitInfoG = @"G:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoG)) _pathUnitInfo = _pathUnitInfoG + @"UnitInfo\";
            string _pathUnitInfoH = @"H:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoH)) _pathUnitInfo = _pathUnitInfoH + @"UnitInfo\";
            string _pathUnitInfoI = @"I:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoI)) _pathUnitInfo = _pathUnitInfoI + @"UnitInfo\";
            string _pathUnitInfoJ = @"J:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoJ)) _pathUnitInfo = _pathUnitInfoJ + @"UnitInfo\";
            string _pathUnitInfoK = @"K:\Pangaea\ExternalExecutables\USBDeviceNCRChecker\";
            if (Directory.Exists(_pathUnitInfoK)) _pathUnitInfo = _pathUnitInfoK + @"UnitInfo\";


            DirectoryInfo DirInfo = new DirectoryInfo(_pathUnitInfo);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }

            using (StreamWriter sw = File.CreateText(_pathUnitInfo + "UnitInfo" + ".txt"))
            {
                sw.WriteLine(_tracer);
                sw.WriteLine(_ID);
                sw.Close();
            }

            //reboot
            Process.Start("shutdown.exe", "-r -t 5");
            timer1.Start();
        }

        //FUNCTION TO INSTALL CUSTOM OS FOR SSCOS
        void MainCustomerImagefunction()
        {
            string _buildtyp = "";
            string _tracer = "";
            string[] _InfoUnit = { };
            int _result = 0;
            string _imageInstalled = "";
            string _LOG = "";
            string _Status = "";
            string _mainDisk = "";
            string _ejl = "";
            bool _isCompleteEjl = false;
            bool _buildTypeExist = false;

            //Reporing Semaphore
            string _OperatorInfo = string.Empty;


            var items = getBuildType();
            _buildtyp = items.Item1;
            _tracer = items.Item2;
            _mainDisk = items.Item3;
            _buildTypeExist = items.Item4;

            _InfoUnit = _UnitInfo.GetSCMC(_tracer);
            string _serialNumber = _InfoUnit[0];
            string _class = _InfoUnit[1];
            string _mc = _InfoUnit[2];

            //UNIT INFO
            lblTracer.Text = "TRACER: " + _tracer;
            lblSN.Text = "SERIAL NUMBER: " + _serialNumber;
            lblClass.Text = "CLASS: " + _class;
            lblMC.Text = "MC: " + _mc;



            //EMPLOYE INFO
            DirectoryInfo _dirInfo = new DirectoryInfo(_mainDisk + _dirUnitInfo);
            FileInfo[] _filesInfo = _dirInfo.GetFiles();
            string[] _unitInfo = File.ReadAllLines(_filesInfo[0].FullName);

            lblID.Text = _unitInfo[1];
            lblName.Text = _ConfigFiles.reader("IMAGES_SERVER", _unitInfo[1], _userFile);
            SlotID = Convert.ToInt32(_unitInfo[3]);
            txtSlotInfo.Text = "SLOT INFO: " + " " + "#" + SlotID.ToString();


            if (!_buildTypeExist)
            {
                MessageBox.Show("Unidad sin build.typ : " + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var _items2 = IsCompleteEJL(_mainDisk, _tracer);
            _ejl = _items2.Item1;
            _isCompleteEjl = _items2.Item2;

            if (!_isCompleteEjl)
            {
                MessageBox.Show("Unidad con log : " + _tracer + ".ejl" + " incompleto" + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            //SKIP THIS PART TO SAVE TIME IN TEST LINE
            //if (!CheckStep(_serialNumber, "FVT"))
            //{
            //    MessageBox.Show("No se puede cargar CUSTOM OS, unidad sin FVT" + "\n" + "\n" + "\n" + "Contacte a Ingenieria de pruebas...", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    return;
            //}

            _OperatorInfo = lblID.Text + "-" + lblName.Text;

            if (_buildtyp.Contains("POSREADY2009_32") || _buildtyp.Contains("POS_READY_2009"))
            {
                _imageInstalled = _POSReady_2009;
                lblImageName.Text = "IMAGE: " + _POSReady_2009;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _POSReady_2009 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WALMART_OS") || _buildtyp.Contains("WALMART_R6LITE_OS"))
            {
                _imageInstalled = _WAL_R6LITE;
                lblImageName.Text = "IMAGE: " + _WAL_R6LITE;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _WAL_R6LITE + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("POSREADY7_64"))
            {
                _imageInstalled = _POS7_64bit;
                lblImageName.Text = "IMAGE: " + _POS7_64bit;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _POS7_64bit + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WINDOWS7PRO_32"))
            {
                _imageInstalled = _Windows7ProfessionalEmbedded32Bit;
                lblImageName.Text = "IMAGE: " + _Windows7ProfessionalEmbedded32Bit;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _Windows7ProfessionalEmbedded32Bit + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }


            if (_buildtyp.Contains("WIN10_64") || _buildtyp.Contains("WIN10_64_VALUE") || _buildtyp.Contains("WIN10_64_ENTERPRISE"))
            {
                _imageInstalled = _XR7_XR6_Win10_IoT_64b_2016;
                lblImageName.Text = "IMAGE: " + _XR7_XR6_Win10_IoT_64b_2016;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _XR7_XR6_Win10_IoT_64b_2016 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WIN7_PEOS_32"))
            {
                _imageInstalled = _Windows7ProfessionalEmbedded32Bit;
                lblImageName.Text = "IMAGE: " + _Windows7ProfessionalEmbedded32Bit;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _Windows7ProfessionalEmbedded32Bit + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WIN7_PEOS_64"))
            {
                _imageInstalled = _XR7_XR6_Win7_PRO_EMBEDDED_64b;
                lblImageName.Text = "IMAGE: " + _XR7_XR6_Win7_PRO_EMBEDDED_64b;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _XR7_XR6_Win7_PRO_EMBEDDED_64b + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WIN10_EEOS_64"))
            {
                _imageInstalled = _XR7_XR6_Win10_IoT_64b_2016;
                lblImageName.Text = "IMAGE: " + _XR7_XR6_Win10_IoT_64b_2016;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _XR7_XR6_Win10_IoT_64b_2016 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("POSREADY7_32") && !_buildtyp.Contains("SKYLAKE"))
            {
                _imageInstalled = _POSReady7_32bit;
                lblImageName.Text = "IMAGE: " + _POSReady7_32bit;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _POSReady7_32bit + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("POSREADY7_32") && _buildtyp.Contains("SKYLAKE"))
            {
                _imageInstalled = _POSREADY7Skylake;
                lblImageName.Text = "IMAGE: " + _POSREADY7Skylake;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _POSREADY7Skylake + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("POS_READY_7EMB"))
            {
                _imageInstalled = _POSReady7_32bit;
                lblImageName.Text = "IMAGE: " + _POSReady7_32bit;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _POSReady7_32bit + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WIN10IOT_64") && _buildtyp.Contains("SKYLAKE"))
            {
                _imageInstalled = _7607_7703_Retail_Win10IoT_2019;
                lblImageName.Text = "IMAGE: " + _7607_7703_Retail_Win10IoT_2019;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _7607_7703_Retail_Win10IoT_2019 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }

            if (_buildtyp.Contains("WIN10IOT_64"))
            {
                _imageInstalled = _7702_7603_Retail_Win10IoT_2019;
                lblImageName.Text = "IMAGE: " + _7702_7603_Retail_Win10IoT_2019;
                _result = ApplyRadsImage(SSSCO_IMAGES_02 + "\"" + _7702_7603_Retail_Win10IoT_2019 + "\"", "", Properties.Settings.Default._applyMode);
                goto FoundIt;
            }



            OnError:
            {
                lblImageName.Text = "";
                MessageBox.Show("NO SE HA ENCONTRADO IMAGEN CUSTOM OS PARA ESTA UNIDAD." + "\n" + "\n" + "\n" + "CONTACTA A INGENIERIA DE PRUEBAS!", "OnError", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            FoundIt:
            {

            }

            //Evualuate result:
            //EXAMPLE CURRENT LOG:
            //TRACER = 10040563
            //DATE = 10 / 25 / 2019 16:56:17.14
            //CUSTOM_OS = POS Ready 7(32 Bit) XR7 Plus Compatible Skylake D370 - 1038 - 0100_01.00.00.02.wim
            //STATUS = PASS

            if (_result == 0)
            {
                _Status = "PASS";

                _LOG = "TRACER=" + _tracer + "\n" +
                       "DATE=" + DateTime.Now.ToString() + "\n" +
                       "CUSTOM_OS=" + _imageInstalled + "\n" +
                       "STATUS=" + _Status + "\n" +
                       _buildtyp;

                lblResult.ForeColor = Color.Green;
                lblResult.Text = "CUSTOM OS: YA PUEDE DESCONECTAR LA UNIDAD!";
                pBoxStatus.Visible = true;
                pBoxStatus.Image = Properties.Resources.GoodMark;

                //Reporting semaphore
                _OperatorInfo = lblID.Text + "-" + lblName.Text;
            }

            if (_result != 0)
            {
                _Status = "FAIL";

                _LOG = "TRACER=" + _tracer + "\n" +
                       "DATE=" + DateTime.Now.ToString() + "\n" +
                       "CUSTOM_OS=" + _imageInstalled + "\n" +
                       "STATUS=" + _Status + "\n" +
                       _buildtyp;

                lblResult.ForeColor = Color.Red;
                lblResult.Text = "CUSTOM OS: No ha sido instalada correctamente...";
                pBoxStatus.Visible = true;
                pBoxStatus.Image = Properties.Resources.BadMark;
            }


            string outputPath = "";
            string reportLog = @"\\mxchim0pangea01\SSCO_IMAGESLogs\";
            outputPath = _LOG_DIR_BK + DateTime.Now.ToString("MM_yyyy_dd") + @"\" + DateTime.Now.ToString("HH") + @"\";
            DirectoryInfo DirInfo = new DirectoryInfo(outputPath);

            if (!DirInfo.Exists)
            {
                DirInfo.Create();
            }

            //create a backup logs in \\mxchim0pangea01\ssco_images\Logs\images\
            using (StreamWriter sw = File.CreateText(outputPath + _tracer + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".txt"))
            {
                _LOG = _LOG.Replace("\n", Environment.NewLine);
                sw.WriteLine(_LOG);
                sw.Close();
            }

            //create a log in \\mxchim0pangea01\SSCO_IMAGESLogs\ to report ifactory step
            using (StreamWriter sw = File.CreateText(reportLog + _tracer + "_" + DateTime.Now.Year + "_" + DateTime.Now.Month + "_" + DateTime.Now.Day + "_" + DateTime.Now.Hour + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + ".txt"))
            {
                _LOG = _LOG.Replace("\n", Environment.NewLine);
                sw.WriteLine(_LOG);
                sw.Close();
            }


            Flag_Trilight _FLAG_TRILIGHT = new Flag_Trilight();
            _FLAG_TRILIGHT._TRACER = _tracer;
            _FLAG_TRILIGHT._DATE = DateTime.Now;
            _FLAG_TRILIGHT._STEP = "BU Arrival";
            _FLAG_TRILIGHT._RESOURCE = "RESOURCE=SBUTT01TE01";
            _FLAG_TRILIGHT._PATH_TARS = @"\\mxchim0pangea01\AUTOMATION_SSCO\TRILIGHT\InProcess\";
            _FLAG_TRILIGHT.SEND_TARS();
        }


        //FUNCTION TO VERIFY THAT JOURNAL IS COMPLETED
        Tuple<string, bool> IsCompleteEJL(string _mainDisk, string _tracer)
        {
            string _ejl = "";
            bool _isComplete = false;

            try
            {
                _ejl = File.ReadAllText(_mainDisk + @":\Mavis\" + _tracer + ".ejl");
                if (_ejl.Contains("* ECHEC") && _ejl.Contains(_tracer)) _isComplete = true;
            }
            catch (Exception ex)
            {
                _isComplete = false;
            }

            return Tuple.Create(_ejl, _isComplete);
        }


        Tuple<string, string, string, bool> getBuildType()
        {

            string _buildTypeDir = "";
            string _MainDisk = "";
            bool _buildTypeExist = false;

            string _buildtypeDirA = @"A:\build.typ";
            if (File.Exists(_buildtypeDirA)) _buildTypeDir = _buildtypeDirA;
            string _buildtypeDirB = @"B:\build.typ";
            if (File.Exists(_buildtypeDirB)) _buildTypeDir = _buildtypeDirB;
            string _buildtypeDirC = @"C:\build.typ";
            if (File.Exists(_buildtypeDirC)) _buildTypeDir = _buildtypeDirC;
            string _buildtypeDirD = @"D:\build.typ";
            if (File.Exists(_buildtypeDirD)) _buildTypeDir = _buildtypeDirD;
            string _buildtypeDirE = @"E:\build.typ";
            if (File.Exists(_buildtypeDirE)) _buildTypeDir = _buildtypeDirE;
            string _buildtypeDirF = @"F:\build.typ";
            if (File.Exists(_buildtypeDirF)) _buildTypeDir = _buildtypeDirF;
            string _buildtypeDirG = @"G:\build.typ";
            if (File.Exists(_buildtypeDirG)) _buildTypeDir = _buildtypeDirG;
            string _buildtypeDirH = @"H:\build.typ";
            if (File.Exists(_buildtypeDirH)) _buildTypeDir = _buildtypeDirH;
            string _buildtypeDirI = @"I:\build.typ";
            if (File.Exists(_buildtypeDirI)) _buildTypeDir = _buildtypeDirI;
            string _buildtypeDirJ = @"J:\build.typ";
            if (File.Exists(_buildtypeDirJ)) _buildTypeDir = _buildtypeDirJ;


            string _buildTypeFeats = "";
            string[] _buildTypeArray = { "" };
            string _tracer = "";

            try
            {
                _MainDisk = _buildTypeDir.Substring(0, 1);
                _buildTypeFeats = File.ReadAllText(_buildTypeDir);
                _buildTypeArray = File.ReadAllLines(_buildTypeDir);
                _tracer = _buildTypeArray[0];
                _buildTypeExist = true;
            }
            catch (Exception ex)
            {
                _buildTypeExist = false;
            }

            return Tuple.Create(_buildTypeFeats, _tracer, _MainDisk, _buildTypeExist);
        }


        //FUNCTION TO GET OS FOR ATMS
        Tuple<string, bool> GetOS(string _class, string _mc)
        {
            string _OS = string.Empty;
            bool _MisanoFeature = false;
            string _FeatFileName = "feat" + _class;
            string[] _content = File.ReadAllLines(_dirFeatures + _FeatFileName);

            foreach (string _line in _content)
            {
                if (_line.Contains(_class + "-MC" + _mc))
                {
                    if (_line.Contains("F810") || _line.Contains("F812")) _MisanoFeature = true;
                    if (_line.Contains("5801P100")) _OS = "WIN10";
                    if (_line.Contains("5801P099")) _OS = "WIN7";
                    if (_line.Contains("5801P060")) _OS = "WIN7";
                    if (_line.Contains("5801P999")) _OS = "WIN7"; // NO OS
                    break;






                }
            }
            return Tuple.Create(_OS, _MisanoFeature);
        }


        //FUNTION TO GET BOARD TYPE
        string getMotherBoardType()
        {
            string _ProductName = "";
            ManagementObjectSearcher _myBaseBoards = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_BaseBoard");

            foreach (ManagementObject mybaseBoard in _myBaseBoards.Get())
            {
                _ProductName = mybaseBoard["Product"].ToString();
            }

            return _ProductName;
        }


        //EVENTS
        private void btnCustomOS_sscos_Click(object sender, EventArgs e)
        {
            //Disable button while the function is running
            btnCustomOS_sscos.Enabled = false;
            //pBoxWaiting2.Visible = true;

            MainCustomerImagefunction();

            //Enable button when the function will be completed
            btnCustomOS_sscos.Enabled = true;
            //pBoxWaiting2.Visible = false;
        }

        private void btnTestImage_sscos_Click(object sender, EventArgs e)
        {
            //Disable button while the function is running            
            string _BaseBoard = getMotherBoardType();

            btnTestImage_sscos.Enabled = false;
            //pBoxWaiting1.Visible = true;

            if (_BaseBoard == "Estoril" || _BaseBoard == "Misano")
            {
                MainTestImageForATMsfunction();
            }

            if (_BaseBoard == "Pocono" || _BaseBoard == "Monaco" || _BaseBoard == "Richmond")
            {

                MainTestImageForSSCOsfunction();
            }

            //Enable button when the function will be completed
            btnTestImage_sscos.Enabled = true;
            //pBoxWaiting1.Visible = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            seconds--;
            if (seconds == 0) timer1.Stop();
            lblResult.Text = "El equipo se reniciara en: " + seconds.ToString();
        }
        #endregion


        #region TabPage Capture image

        //FUNCTION TO INITIALIZE LIST VIEWS
        private void initListViews()
        {
            // Add columns
            lvDescription_capture.View = View.Details;
            lvDescription_capture.Columns.Add("Drive", 50, HorizontalAlignment.Left);
            lvDescription_capture.Columns.Add("Description", 180, HorizontalAlignment.Left);
            lvDescription_capture.Columns.Add("Size", 100, HorizontalAlignment.Left);
            lvDescription_capture.Columns.Add("Partitions", 65, HorizontalAlignment.Left);

            lvPartition_capture.View = View.Details;
            lvPartition_capture.Columns.Add("Partition", 60, HorizontalAlignment.Left);
            lvPartition_capture.Columns.Add("Type", 100, HorizontalAlignment.Left);
            lvPartition_capture.Columns.Add("Size", 100, HorizontalAlignment.Left);
            lvPartition_capture.Columns.Add("Used", 100, HorizontalAlignment.Left);

            lvFilesView_capture.View = View.Details;
            lvFilesView_capture.Columns.Add("File", 250, HorizontalAlignment.Left);
            lvFilesView_capture.Columns.Add("Size", 150, HorizontalAlignment.Left);
            lvFilesView_capture.Columns.Add("Date", 200, HorizontalAlignment.Left);
        }

        //FUNCTION TO LIST ALL FILES INSADE OF FOLDER
        void ListAllFilesFromServer(string Server, bool SubFolder)
        {
            //string[] split = Server.Split(' ');
            //string _root = split[0];
            //string _path = split[1];
            string _ServerDir = string.Empty;
            if (!SubFolder) _ServerDir = Server.Substring(0, 2);
            if (SubFolder) _ServerDir = Server;

            try
            {
                DirectoryInfo _dirInfo = new DirectoryInfo(_ServerDir);
                //DirectoryInfo _dirInfo = new DirectoryInfo(_path);
                DirectoryInfo[] _dircInfo = _dirInfo.GetDirectories();
                FileInfo[] _filesInfo = _dirInfo.GetFiles();
                //FileInfo[] _filesInfo = _dirInfo.GetFiles("*.wim"); origi

                lvFilesView_capture.Items.Clear();

                foreach (DirectoryInfo _directoryInfo in _dircInfo)
                {
                    var item = new ListViewItem(new[] { _directoryInfo.Name, "", _directoryInfo.CreationTime.ToString() });
                    lvFilesView_capture.Items.Add(item);
                }

                foreach (FileInfo _fileInfo in _filesInfo)
                {
                    var item = new ListViewItem(new[] { _fileInfo.Name, _fileInfo.Length.ToString(), _fileInfo.CreationTime.ToString() });
                    lvFilesView_capture.Items.Add(item);
                }
            }
            catch (Exception ex)
            {

            }
        }

        //FUNCTION TO FILL LIST VIEW WITH ALL DEVICES CONNECTED IN CPU
        void FillListAllDisk()
        {
            try
            {
                ManagementObjectSearcher _myDisks = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
                lvDescription_capture.Items.Clear();
                lvPartition_capture.Items.Clear();
                foreach (ManagementObject myDisk in _myDisks.Get())
                {
                    var item = new ListViewItem(new[] { myDisk["Index"].ToString(), myDisk["Model"].ToString(), myDisk["Size"].ToString(), myDisk["Partitions"].ToString() });
                    var item2 = new ListViewItem(new[] { myDisk["Partitions"].ToString(), myDisk["MediaType"].ToString(), myDisk["Size"].ToString(), "" });
                    lvDescription_capture.Items.Add(item);
                    lvPartition_capture.Items.Add(item2);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        //EVENTS
        private void lvFilesView_capture_Click(object sender, EventArgs e)
        {
            var fisrtSelectionedItem = lbSaveImage_capture.Text;
            string[] split = fisrtSelectionedItem.Split(' ');
            string _root = split[0];
            string _path = split[1];
            var SecondSelectedItem = lvFilesView_capture.SelectedItems[0];
            string _subFolder = SecondSelectedItem.Text;
            _tempSubFolder = _tempSubFolder + "\\" + _subFolder;
            _subFolder = _path + "\\" + _tempSubFolder;

            ListAllFilesFromServer(_subFolder, true);
        }

        private void lbSaveImage_capture_SelectedIndexChanged(object sender, EventArgs e)
        {
            _tempSubFolder = "";
            _tempServer = lbSaveImage_capture.Text;
            _tempServer = _tempServer.Substring(0, 2);
            ListAllFilesFromServer(lbSaveImage_capture.Text, false);
        }

        private void lvDescription_capture_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                _tempDrive = lvDescription_capture.SelectedItems[0].Text;
            }
            catch (Exception ex)
            {

            }
        }

        private void btnCapture_capture_Click(object sender, EventArgs e)
        {
            if (txtImageName_capture.Text == "") return;
            if (_tempServer == "") return;
            if (_tempDrive == "") return;

            ManagementObjectSearcher _myDisks = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
            ManagementObjectCollection _disks = _myDisks.Get();
            List<ManagementObject> moList = _disks.Cast<ManagementObject>().ToList();
            string _dName = moList[Convert.ToInt32(_tempDrive)]["Model"].ToString();


            string _label = "You are about to capture the 1 partition on drive " + _tempDrive + " " + "[" + _dName + "]" + " " + "to " + _tempServer + "\\" + txtImageName_capture.Text;

            DialogResult dr = new DialogResult();
            dr = MessageBox.Show(_label, "Capture image", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.OK) CaptureRadsImage(_tempDrive, txtImageName_capture.Text, _tempServer, Properties.Settings.Default._captureMode);
        }

        private void rbtnSite_capture_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default._captureMode = "SITE";
            Properties.Settings.Default.Save();
        }

        private void rbtnUser_catpure_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default._captureMode = "USER";
            Properties.Settings.Default.Save();

        }

        private void rbtnFactory_capture_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default._captureMode = "FACTORY";
            Properties.Settings.Default.Save();
        }

        private void btnCapture_Refresh_Click(object sender, EventArgs e)
        {
            FillListAllDisk();

            string[] _result = ListAllDrives();

            lbAllDrives_settings.Items.Clear();
            lbImagesServer_apply.Items.Clear();
            lbSaveImage_capture.Items.Clear();

            foreach (string _drive in _result)
            {
                lbAllDrives_settings.Items.Add(_drive);
                lbImagesServer_apply.Items.Add(_drive);
                lbSaveImage_capture.Items.Add(_drive);
            }
        }

        #endregion

        #region TabPage Apply image

        void GetImagesFilesFromSever(string Server)
        {
            //string[] split = Server.Split(' ');
            //string _root = split[0];
            //string _path = split[1];
            string _ServerDir = Server.Substring(0, 2);
            DirectoryInfo _dirInfo = new DirectoryInfo(_ServerDir);
            //DirectoryInfo _dirInfo = new DirectoryInfo(_path);
            FileInfo[] _filesInfo = _dirInfo.GetFiles("*.wim");

            lbImagesToApply_apply.Items.Clear();
            foreach (FileInfo _fileInfo in _filesInfo)
            {
                lbImagesToApply_apply.Items.Add(_ServerDir + "\"" + _fileInfo.Name + "\"");
            }
        }

        private void lbImagesServer_apply_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetImagesFilesFromSever(lbImagesServer_apply.Text);
        }

        private void btnApply_Refresh_Click(object sender, EventArgs e)
        {
            string[] _result = ListAllDrives();

            lbAllDrives_settings.Items.Clear();
            lbImagesServer_apply.Items.Clear();
            lbSaveImage_capture.Items.Clear();

            foreach (string _drive in _result)
            {
                lbAllDrives_settings.Items.Add(_drive);
                lbImagesServer_apply.Items.Add(_drive);
                lbSaveImage_capture.Items.Add(_drive);
            }
        }

        private void btnApply_apply_Click(object sender, EventArgs e)
        {
            if (lbImagesToApply_apply.SelectedIndex == -1) return;
            ApplyRadsImage(lbImagesToApply_apply.Text, "/reboot ", Properties.Settings.Default._applyMode);
        }

        private void rbtnSite_apply_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default._applyMode = "SITE";
            Properties.Settings.Default.Save();
        }

        private void rbtnUser_apply_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default._applyMode = "USER";
            Properties.Settings.Default.Save();
        }

        private void rbtnFactory_apply_CheckedChanged(object sender, EventArgs e)
        {
            Properties.Settings.Default._applyMode = "FACTORY";
            Properties.Settings.Default.Save();
        }
        #endregion


        #region TabPage Network drives


        //Event to refresh mapping drives
        private void btnRefreshDrives_settings_Click(object sender, EventArgs e)
        {
            string[] _result = ListAllDrives();

            lbAllDrives_settings.Items.Clear();
            lbImagesServer_apply.Items.Clear();
            lbSaveImage_capture.Items.Clear();

            foreach (string _drive in _result)
            {
                lbAllDrives_settings.Items.Add(_drive);
                lbImagesServer_apply.Items.Add(_drive);
                lbSaveImage_capture.Items.Add(_drive);
            }
        }

        //Event to map a new drive
        private void btnMap_settings_Click(object sender, EventArgs e)
        {
            if (cbLetter_settings.SelectedIndex == -1) return;
            if (txtServer_settings.Text == "") return;
            if (cbDomain_settings.Text == "") return;
            if (txtUser_settings.Text == "") return;
            if (txtPassword_settings.Text == "") return;

            int _result = MapNewDrive(cbLetter_settings.Text, txtServer_settings.Text, cbDomain_settings.Text, txtUser_settings.Text, txtPassword_settings.Text);

            if (_result != 0) MessageBox.Show("Invalid Mapping network. " + cbLetter_settings.Text + txtServer_settings.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            if (_result == 0) MessageBox.Show("OK to Mapping network. " + cbLetter_settings.Text + txtServer_settings.Text, "Done", MessageBoxButtons.OK, MessageBoxIcon.None);

            txtServer_settings.Clear();
            txtUser_settings.Clear();
            txtPassword_settings.Clear();

            btnRefreshDrives_settings_Click(sender, e);
        }

        private void btnRemoveDrive_settings_Click(object sender, EventArgs e)
        {
            if (cbLetterToRemove_settings.SelectedIndex == -1) return;

            int _result = RemoveDrive(cbLetterToRemove_settings.Text);

            if (_result != 0) MessageBox.Show("Invalid Mapping network. " + cbLetter_settings.Text, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            if (_result == 0) MessageBox.Show("OK to remove network. " + cbLetterToRemove_settings.Text, "Done", MessageBoxButtons.OK, MessageBoxIcon.None);

            btnRefreshDrives_settings_Click(sender, e);
        }

        #endregion


        #region funciones genericas

        //function to apply image with radsimageX.exe
        int ApplyRadsImage(string Image, string Reboot, string _ApplyMode)
        {
            string _image = Image;
            int _result = 0;

            try
            {
                //_image = Reboot + _ApplyArgStart + _image + _ApplyArgEnd;
                _image = Reboot + _ApplyArgStart + _image + " " + _ApplyMode + _ApplyArgEnd;
                _result = ExternalExe(_RadsImage, _image);

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return _result;
        }


        #region Microsoft ImageX tool

        int BootFiles() //function to copying bootfiles after to apply image
        {
            int _result = 0;

            try
            {
                _result = ExternalExe(_bootsect, "/nt60 c:");
                _result = ExternalExe(_bcdBoot, @"c:\windows");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return _result;
        }

        int FormatDisk() //function to format Disk Diskpart tool
        {
            this.TopMost = false;
            int _result = 0;
            Process p = new Process();
            p.StartInfo.WindowStyle = ProcessWindowStyle.Maximized;
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.FileName = @"X:\Windows\System32\diskpart.exe";
            p.StartInfo.RedirectStandardInput = true;
            p.Start();

            //Script First Partition System Boot Files
            p.StandardInput.WriteLine("select disk 0");
            p.StandardInput.WriteLine("clean");
            p.StandardInput.WriteLine("create partition primary size=300");
            p.StandardInput.WriteLine("select partition 1");
            p.StandardInput.WriteLine("format fs=ntfs quick label=System");
            p.StandardInput.WriteLine("assign letter=D");
            p.StandardInput.WriteLine("active");

            //Second partition Operation System Windows
            p.StandardInput.WriteLine("create partition primary");
            p.StandardInput.WriteLine("select partition 2");
            p.StandardInput.WriteLine("format fs = ntfs quick label=Windows");
            p.StandardInput.WriteLine("assign letter=C");
            p.StandardInput.WriteLine("exit");
            //Script

            string output = p.StandardOutput.ReadToEnd();
            p.WaitForExit();

            string[] split = output.Split('\n');

            foreach (string Message in split)
            {
                if (Message.Contains("DiskPart successfully formatted the volume."))
                {
                    _result++;
                }
            }

            return _result;
        }

        void CaptureImageX(string Drive, string Path, string ImageName)
        {
            //imagex.exe /capture c: z:\BK-CL1.wim "BK-CL1" /verify example to use the imagex in winPENET
            this.TopMost = false;
            int _result = 0;

            try
            {
                string _InputArgs = "/capture " + Drive + " " + Path + "\\" + ImageName + " " + "\"" + string.Concat(ImageName.Reverse().Skip(4).Reverse()) + "\"" + " " + "/verify";

                _result = ExternalExe(_ImageX, _InputArgs);

                if (_result != 0) MessageBox.Show("La imagen no pudo ser capturada...");
                if (_result == 0) MessageBox.Show("Se capturo la imagen correctamente!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            this.TopMost = true;
        }

        int ApplyImgImageX(string Image)  //function to apply image with ImageX.exe
        {
            //new image X

            string _image = Image;
            int _result = 0;

            //Image = Image.Insert(2, "\\");

            try
            {
                string _args = "/apply " + Image + " 1" + " C:";
                _result = ExternalExe(_ImageX, _args);


                MessageBox.Show(_result.ToString());
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            return _result;
        }

        private void btnCaptureImageX_Click(object sender, EventArgs e)
        {
            if (txtImageName_capture.Text == "") return;
            if (_tempServer == "") return;
            if (_tempDrive == "") return;

            ManagementObjectSearcher _myDisks = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
            ManagementObjectCollection _disks = _myDisks.Get();
            List<ManagementObject> moList = _disks.Cast<ManagementObject>().ToList();
            string _dName = moList[Convert.ToInt32(_tempDrive)]["Model"].ToString();


            string _label = "You are about to capture the 1 partition on drive " + _tempDrive + " " + "[" + _dName + "]" + " " + "to " + _tempServer + "\\" + txtImageName_capture.Text;


            using (ManagementClass devs = new ManagementClass(@"Win32_Diskdrive"))
            {
                ManagementObjectCollection moc = devs.GetInstances();
                foreach (ManagementObject mo in moc)
                {
                    foreach (ManagementObject b in mo.GetRelated("Win32_DiskPartition"))
                    {
                        foreach (ManagementBaseObject c in b.GetRelated("Win32_LogicalDisk"))
                        {
                            _tempDrive = c["Name"].ToString();
                        }

                    }
                }
            }

            //string _args = "/capture" + " " + _tempDrive + " " + _tempServer + "\\" + txtImageName_capture.Text + " " + "\"" + string.Concat(txtImageName_capture.Text.Reverse().Skip(4).Reverse()) + "\"" + " " + "/verify";
            //MessageBox.Show("/capture" +" "+ _tempDrive +" "+ _tempServer +"\\"+ txtImageName_capture.Text + " " + "\"" + string.Concat(txtImageName_capture.Text.Reverse().Skip(4).Reverse()) + "\"" + " " + "/verify");

            DialogResult dr = new DialogResult();
            dr = MessageBox.Show(_label, "Capture image", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation);
            if (dr == DialogResult.OK) CaptureImageX(_tempDrive, _tempServer, txtImageName_capture.Text);
        }

        private void btn_ImagexApply_Click(object sender, EventArgs e)
        {
            if (lbImagesToApply_apply.SelectedIndex == -1) return;
            this.TopMost = false;
            FormatDisk();
            ApplyImgImageX(lbImagesToApply_apply.Text);
            BootFiles();
            this.TopMost = true;
            MessageBox.Show(lbImagesToApply_apply.Text + " has been applied correctly" + "\n" + "Now you can reboot the system.");
        }

        #endregion

        void CaptureRadsImage(string Drive, string ImageName, string Path, string CaptureMode)
        {
            //RadsImageX.exe /capture 0 D:\Name.wim Site or User example
            string _driveNumber = Drive + " ";
            string _imageName = ImageName;
            string _path = Path;
            string _captureMode = CaptureMode;
            string _Args = "";
            int _result = 0;

            try
            {
                _Args = _CaptureArgsStart + _driveNumber + _path + "\"" + _imageName + "\"" + " " + _captureMode;
                _result = ExternalExe(_RadsImage, _Args);

                if (_result == 1) MessageBox.Show("La imagen no pudo ser capturada...");
                if (_result == 0) MessageBox.Show("Se capturo la imagen correctamente!");
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //Function to map a new drive
        int MapNewDrive(string letterDrive, string Server, string Domain, string User, string Password)
        {
            //net use Z: "\\mxchim0pangea01\ATM_IMAGES" /USER:Jabil\Testsystems Mav1sATMGl0bal
            string _NetProc = "net.exe";
            string _args1 = "use ";
            string _args2 = "/USER:";
            Server = "\"" + Server + "\"";
            string _ArgsToMap = _args1 + letterDrive + " " + Server + " " + _args2 + Domain + User + " " + Password;

            int _result = ExternalExe(_NetProc, _ArgsToMap);

            return _result;
        }

        int RemoveDrive(string letter)
        {
            string _NetProc = "net.exe";
            string _ArgsToRemove = @"use " + letter + " " + "/delete";
            int _result = ExternalExe(_NetProc, _ArgsToRemove);
            return _result;
        }

        //Function to initialize an external application and wait for finish process and return the exit code from external application
        int ExternalExe(string FileName, string Args)
        {
            int _result = 0;
            Process _process = new Process();
            _process.StartInfo.FileName = FileName;
            _process.StartInfo.Arguments = Args;
            _process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            _process.Start();
            _process.WaitForExit();
            _result = _process.ExitCode;
            return _result;
        }

        //Function to use imageX
        bool EventHandled = false;
        int ImageX(string FileName, string Args)
        {
            int _result = 0;
            Process _process = new Process();
            _process.StartInfo.FileName = FileName;
            _process.StartInfo.Arguments = Args;
            _process.StartInfo.WindowStyle = ProcessWindowStyle.Normal;
            _process.Start();
            _process.Exited += _process_Exited;

            while (!EventHandled)
            {

            }

            _result = _process.ExitCode;
            return _result;
        }

        private void _process_Exited(object sender, EventArgs e)
        {
            EventHandled = true;
        }

        string[] ListAllDrives()
        {
            List<string> _list = new List<string>();
            DriveInfo[] _DrivesInfo = DriveInfo.GetDrives();

            foreach (DriveInfo _driveInfo in _DrivesInfo)
            {
                DirectoryInfo dir = _driveInfo.RootDirectory;
                var unc = GetUNCPath(dir.FullName.Substring(0, 2));

                _list.Add(_driveInfo.Name + " " + unc);
            }
            return _list.ToArray();
        }

        //get the full path to drive mapping
        public static string GetUNCPath(string path)
        {
            if (path.StartsWith(@"\\"))
                return path;

            ManagementObject mo = new ManagementObject();
            mo.Path = new ManagementPath(string.Format("Win32_LogicalDisk='{0}'", path));

            //DriveType 4 = Network Drive
            if (Convert.ToUInt32(mo["DriveType"]) == 4)
                return Convert.ToString(mo["ProviderName"]);
            else return path;
        }


        //Function to list all hard disk connected
        void ListAllDisk()
        {
            ManagementObjectSearcher _myDisks = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");

            foreach (ManagementObject myDisk in _myDisks.Get())
            {
                MessageBox.Show(myDisk["Model"].ToString());
            }
        }

        #endregion


        #region Setup Current images

        void SetupTestImage()
        {
            string _configPath = @"\\mxchim0pangea01\AUTOMATION_SSCO\IMAGES_SERVER_2.0\ConfigFile\SetupTestImages.ini";
            _TestImage7703 = _ConfigFiles.reader("SSCO", "TestImage7703", _configPath);
            _TestImage7358 = _ConfigFiles.reader("SSCO", "TestImage7358", _configPath);
            _TestImage7360 = _ConfigFiles.reader("SSCO", "TestImage7360", _configPath);
            _TestImage7362 = _ConfigFiles.reader("SSCO", "TestImage7362", _configPath);
            _TestImage7350R6L = _ConfigFiles.reader("SSCO", "TestImage7350R6L", _configPath);
            _TestImage7350R5 = _ConfigFiles.reader("SSCO", "TestImage7350R5", _configPath);

            _TestImageEstoril_Windows7 = _ConfigFiles.reader("ATM", "TestImageEstoril_Windows7", _configPath);
            _TestImageEstoril_Windows10 = _ConfigFiles.reader("ATM", "TestImageEstoril_Windows10", _configPath);
            _TestImageMisano_Windows7 = _ConfigFiles.reader("ATM", "TestImageMisano_Windows7", _configPath);
            _TestImageMisano_Windows10 = _ConfigFiles.reader("ATM", "TestImageMisano_Windows10", _configPath);
        }

        #endregion


        //temporal function...
        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //SoundPlayer logout = new SoundPlayer(Properties.Resources.Marrano);
            //logout.Play();
            //RegistryKey key = Registry.LocalMachine.CreateSubKey(@"System\CurrentControlSet\Control");
            //object value = key.GetValue("PEFirmwareType");
            //MessageBox.Show(value.ToString());

            //ManagementObjectSearcher theSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive WHERE InterfaceType='USB'");
            //foreach (ManagementObject currentObject in theSearcher.Get())
            //{
            //    ManagementObject theSerialNumberObjectQuery = new ManagementObject("Win32_PhysicalMedia.Tag='" + currentObject["DeviceID"] + "'");
            //    //MessageBox.Show(theSerialNumberObjectQuery["SerialNumber"].ToString());
            //}
            //this.TopMost = false;

            //int value1 = ExternalExe("diskpart", @"/s y:\\mxchim0pangea01\AUTOMATION_SSCO\IMAGES_SERVER_2.0\Download\diskpartScript\ScriptDiskPart.txt");
            //MessageBox.Show(value1.ToString());

            //int value = ImageX(_ImageX, "/apply w:POSReady_2009.wim 1 c:");
            //MessageBox.Show(value.ToString());            
        }

        private void btnTab1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectedTab = tabPage1;
        }

        private void btnTab2_Click(object sender, EventArgs e)
        {
            //DialogResult dr = new DialogResult();
            //AdminUser Admin = new AdminUser();

            //dr = Admin.ShowDialog();
            //if (dr != DialogResult.OK) return;

            tabControl1.SelectedTab = tabPage3;
        }

        private void btnTab3_Click(object sender, EventArgs e)
        {
            //DialogResult dr = new DialogResult();
            //AdminUser Admin = new AdminUser();

            //dr = Admin.ShowDialog();
            //if (dr != DialogResult.OK) return;        

            tabControl1.SelectedTab = tabPage4;
        }

        private void btnTab4_Click(object sender, EventArgs e)
        {
            //DialogResult dr = new DialogResult();
            //AdminUser Admin = new AdminUser();

            //dr = Admin.ShowDialog();
            //if (dr == DialogResult.OK) return;

            tabControl1.SelectedTab = tabPage5;
        }

        private void lvFilesView_capture_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {

            }
        }

        private void lvFilesView_capture_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.C)
            {
                ListView.SelectedListViewItemCollection selectedItems = lvFilesView_capture.SelectedItems;
                String text = "";
                foreach (ListViewItem item in selectedItems)
                {
                    text += item.Text;
                }
                Clipboard.SetText(text);
            }


            if (e.KeyCode == Keys.Back)
            {
                lbSaveImage_capture_SelectedIndexChanged(sender, e);
            }

            if (e.KeyCode == Keys.Enter)
            {
                lvFilesView_capture_Click(sender, e);
            }
        }











        #region WIMGAPI 
        WimMessageCallback wimMessageCallback;
        CopyFileProgressCallback copyFileProgressCallback;
        CopyFileProgress _copyFiles;
        WimMessageResult _WimMessageResult;
        WimHandle _handleByCapturingImg;

        private static readonly CancellationTokenSource CancellationTokenSource = new CancellationTokenSource();

        //Release Function to Capture Image WIMGAPI
        void WIMGAPI_CaptureImage()
        {
            try
            {
                // Open a handle to the .wim file
                WimHandle _handle = WimgApi.CreateFile(@"W:\Test_LZX_Compress.wim",
                                                        WimFileAccess.Write,
                                                        WimCreationDisposition.CreateAlways,
                                                        WimCreateFileOptions.Verify,
                                                        WimCompressionType.Lzx);
                try
                {
                    //Always create a temporal path to create a temporal files during the capture
                    WimgApi.SetTemporaryPath(_handle, @"W:\");

                    //Create delegate to get information during de capturing image
                    //wimMessageCallback = new WimMessageCallback(WimCallBack); verify if is necessary create a instance

                    //Register the callback method with the specific handle returned by wimgapi.CreateFile
                    WimgApi.RegisterMessageCallback(_handle, WimCallBackMethod);

                    //Call function to Capture the image
                    //_handleByCapturingImg = WimgApi.CaptureImage(_handle, @"D:\", WimCaptureImageOptions.None);

                    WimgApi.RegisterLogFile(@"W:\logfileResult.txt");


                    using (_handleByCapturingImg = WimgApi.CaptureImage(_handle, @"D:\", WimCaptureImageOptions.None))
                    {

                        XmlDocument xmlDocument = new XmlDocument();
                        XmlDocumentFragment fragment = xmlDocument.CreateDocumentFragment();
                        string xmldata = $"<IMAGE><NAME>IMAGEN BY PACO</NAME><DESCRIPTION>IMAGEN BY PACO</DESCRIPTION></IMAGE>";
                        fragment.InnerXml = xmldata;
                        xmlDocument.AppendChild(fragment);
                        WimgApi.SetImageInformation(_handleByCapturingImg, xmlDocument);
                    }
                }
                finally
                {


                    WimgApi.UnregisterLogFile(@"W:\logfileResult.txt");

                    // Be sure to unregister the callback method                    
                    WimgApi.UnregisterMessageCallback(_handle, WimCallBackMethod);

                }


                //Be sure that close the handle for the capturing image next close the handle for the createfile
                //_handleByCapturingImg.Dispose();
                _handle.Dispose();

                MessageBox.Show("Capture Image Finished");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btnCaptureWimGapi_Click(object sender, EventArgs e)
        {
            WIMGAPI_CaptureImage();
        }

        private WimMessageResult WimCallBackMethod(WimMessageType _MessageType, object _message, object _userData)
        {
            // This method is called for every single action during the process being executed.
            // In the case of apply, you'll get Progress, Info, Warnings, Errors, etc
            //
            // The trick is to determine the message type and cast the "message" param to the corresponding type
            //
            _WimMessageResult = WimMessageResult.Done;

            switch (_MessageType)
            {
                case WimMessageType.Progress:  // Some progress is being sent

                    // Get the message as a WimMessageProgress object
                    //
                    WimMessageProgress progressMessage = (WimMessageProgress)_message;

                    // Print the progress
                    //
                    lblProgress.Text = "progress: " + progressMessage.PercentComplete.ToString("#0.##%");
                    lblEstimatedTime.Text = "Estimated Time Remaining: " + progressMessage.EstimatedTimeRemaining.TotalMinutes.ToString();
                    lblEstimatedTime.Refresh();
                    lblProgress.Refresh();
                    break;


                case WimMessageType.Process:  // Some progress is being sent

                    // Get the message as a WimMessageProgress object
                    //
                    WimMessageProcess processMessage = (WimMessageProcess)_message;

                    // Print the Current file 
                    //
                    lblFilesInfo.Text = "File: " + processMessage.Path;
                    lblFilesInfo.Refresh();
                    break;

                case WimMessageType.Scanning:  // Some progress is being sent

                    // Get the message as a WimMessageProgress object
                    //
                    WimMessageScanning scanningMessage = (WimMessageScanning)_message;

                    // Print the Current file 
                    //
                    lblCountFiles.Text = "Count Files: " + scanningMessage.Count.ToString();
                    lblCountFiles.Refresh();
                    break;


                case WimMessageType.Compress:  // Some progress is being sent

                    // Get the message as a WimMessageProgress object
                    //
                    WimMessageCompress compressMessage = (WimMessageCompress)_message;

                    // Print the Current file 
                    //
                    lblFilesInfo.Text = "Compress File: " + compressMessage.Path;
                    lblFilesInfo.Refresh();
                    break;


                case WimMessageType.Warning:  // A warning is being sent

                    // Get the message as a WimMessageProgress object
                    //
                    WimMessageWarning warningMessage = (WimMessageWarning)_message;

                    // Print the file and error code
                    //
                    _WimMessageResult = WimMessageResult.Abort;
                    break;

                case WimMessageType.Error:  // An error is being sent

                    // Get the message as a WimMessageError object
                    //
                    WimMessageError errorMessage = (WimMessageError)_message;

                    // Print the file and error code
                    //
                    Console.WriteLine("Error: {0} ({1})", errorMessage.Path, errorMessage.Win32ErrorCode);
                    _WimMessageResult = WimMessageResult.Abort;
                    break;
            }

            // Depending on what this method returns, the WIMGAPI will continue or cancel.
            //
            // Return WimMessageResult.Abort to cancel.  In this case we return Success so WIMGAPI keeps going


            if (CancellationTokenSource.IsCancellationRequested)
            {
                _WimMessageResult = WimMessageResult.Abort;
            }

            Console.WriteLine("Sleeping...");
            try
            {
                //Task.Delay(1000, CancellationTokenSource.Token).Wait();
            }
            catch (TaskCanceledException)
            {

            }


            return _WimMessageResult;
        }


        private CopyFileProgressAction copyFileCallBack(Microsoft.Wim.CopyFileProgress copyFileProgress, object Data)
        {
            lblFilesInfo.Text = copyFileProgress.EstimatedTimeRemaining.TotalMinutes.ToString();
            lblCountFiles.Text = copyFileProgress.PercentComplete.ToString();
            this.Refresh();

            return CopyFileProgressAction.Continue;
        }


        #endregion

        private void btnAbortWimgapi_Click(object sender, EventArgs e)
        {
            //wimMessageCallback = new WimMessageCallback(WimCallBackMethod);
            //WimgApi.RegisterMessageCallback(wimMessageCallback);

            //copyFileProgressCallback = new CopyFileProgressCallback(copyFileCallBack);

            //WimgApi.CopyFile(@"\\mxchim0pangea01\SSCO_IMAGES\Test_Mount.wim", @"\\mxchim0pangea01\SSCO_IMAGES\Test_Copy.wim", WimCopyFileOptions.None, copyFileProgressCallback, "");


            //WimgApi.UnregisterMessageCallback(wimMessageCallback);

            CancellationTokenSource.Cancel();
            
        }
    }
}
